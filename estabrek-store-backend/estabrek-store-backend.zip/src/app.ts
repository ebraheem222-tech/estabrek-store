// src/app.ts
import express from "express";
import cors from "cors";
import morgan from "morgan";
import path from "path";

import { env, parseOrigins } from "./config/env.js";
import routes from "./routes/index.js";
import { errorHandler } from "./middleware/error.js";
import { requestId } from "./middleware/requestId.js";
import { rateLimit } from "./middleware/rateLimit.js";
import { cacheControl } from "./middleware/cacheControl.js";
import webhooksRouter from "./routes/webhooks.route.js"; // عدّل المسار حسب مشروعك

const app = express();

// useful when behind a proxy / docker / nginx
app.set("trust proxy", true);

// global middleware
app.use(requestId);
app.use(cors({ origin: parseOrigins(env.CORS_ORIGINS), credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(morgan(env.NODE_ENV === "production" ? "combined" : "dev"));
app.use(cacheControl);
app.use(rateLimit);

// health + root
app.get("/health", (_req, res) => res.json({ ok: true, name: "estabrak-store" }));
app.get("/", (_req, res) => res.json({ ok: true, api: "/v1" }));
// versioned routes
app.use("/uploads", express.static(path.resolve(process.cwd(), "uploads")));

app.use(routes);
app.use("/v1/webhooks", webhooksRouter);

// 404 (before error handler)
app.use((req, res) => res.status(404).json({ error: "NOT_FOUND", path: req.path }));

// central error handler
app.use(errorHandler);

export default app;
