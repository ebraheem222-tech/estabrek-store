// src/config/env.ts
import "dotenv/config";
import { z } from "zod";

/** Parse comma-separated origins into array or "*" */
export function parseOrigins(raw: string): (string | RegExp)[] | "*" {
  const s = raw.trim();
  if (s === "" || s === "*") return "*";
  return s
    .split(",")
    .map((p) => p.trim())
    .filter(Boolean)
    .map((o) =>
      o.startsWith("/") && o.endsWith("/") ? new RegExp(o.slice(1, -1)) : o
    );
}

const EnvSchema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().default(4000),

  DATABASE_URL: z.string().url(),

  // Auth / security
  JWT_SECRET: z.string().min(16, "JWT_SECRET must be at least 16 chars"),
  WEBHOOK_TOKEN: z
    .string()
    .min(16, "WEBHOOK_TOKEN must be at least 16 chars")
    .default("dev-webhook-please-change-123456"), // long enough to satisfy .min

  // CORS & rate limit
  CORS_ORIGINS: z.string().default("*"),
  RATE_LIMIT_WINDOW_MS: z.coerce.number().default(60_000),
  RATE_LIMIT_MAX: z.coerce.number().default(120),

  // Brute-force protection
  AUTH_MAX_FAILED: z.coerce.number().int().min(3).max(20).default(5),
  AUTH_LOCK_MINUTES: z.coerce.number().int().min(1).max(1440).default(15),

  // OTP (SMS/email) settings
  OTP_TTL_MINUTES: z.coerce.number().int().min(1).max(60).default(5),
  OTP_MAX_ATTEMPTS: z.coerce.number().int().min(3).max(20).default(5),

  // Messaging provider (optional). Default senders are stubs.
  SMS_FROM: z.string().optional(),
  TWILIO_ACCOUNT_SID: z.string().optional(),
  TWILIO_AUTH_TOKEN: z.string().optional(),
  TWILIO_FROM: z.string().optional(),

  // Optional: trust proxy for real client IP behind reverse proxies
  TRUST_PROXY: z
    .union([z.enum(["0", "1", "true", "false"]), z.coerce.number()])
    .optional()
    .transform((v) => (v == null ? false : v === "1" || v === "true" || Number(v) > 0)),
});

const parsed = EnvSchema.safeParse(process.env);
if (!parsed.success) {
  console.error("❌ Invalid environment variables:");
  for (const [key, msgs] of Object.entries(parsed.error.flatten().fieldErrors)) {
    console.error(`  - ${key}: ${msgs?.join(", ")}`);
  }
  process.exit(1);
}

export const env = parsed.data;
export type AppEnv = z.infer<typeof EnvSchema>;

/** Parsed CORS origins ready for `cors({ origin })` */
export const corsOrigins = parseOrigins(env.CORS_ORIGINS);
