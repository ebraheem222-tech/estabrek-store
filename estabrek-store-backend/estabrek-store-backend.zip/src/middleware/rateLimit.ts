import type { RequestHandler } from "express";
import { env } from "../config/env.js";

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

export const rateLimit: RequestHandler = (req, res, next) => {
  const key = `${req.ip}:${req.path}`;
  const now = Date.now();
  const ttl = env.RATE_LIMIT_WINDOW_MS;

  let b = buckets.get(key);
  if (!b || b.resetAt <= now) {
    b = { count: 0, resetAt: now + ttl };
    buckets.set(key, b);
  }

  b.count += 1;
  const remaining = Math.max(0, env.RATE_LIMIT_MAX - b.count);

  res.setHeader("X-RateLimit-Limit", env.RATE_LIMIT_MAX.toString());
  res.setHeader("X-RateLimit-Remaining", remaining.toString());
  res.setHeader("X-RateLimit-Reset", Math.ceil(b.resetAt / 1000).toString());

  if (b.count > env.RATE_LIMIT_MAX) {
    return res.status(429).json({ error: "RATE_LIMIT", retryAt: b.resetAt });
  }
  next();
};
