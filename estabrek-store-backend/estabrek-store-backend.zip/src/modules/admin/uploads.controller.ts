// src/modules/admin/uploads.controller.ts
import { Router } from "express";
import multer from "multer";
import path from "path";
import fs from "fs/promises";
import sharp from "sharp";

import { prisma } from "../../lib/prisma.js";

const r = Router();

const UPLOAD_ROOT = path.resolve(process.cwd(), "uploads");
const IMAGES_DIR = path.join(UPLOAD_ROOT, "images");

const storage = multer.diskStorage({
  destination: async (_req, _file, cb) => {
    try {
      await fs.mkdir(IMAGES_DIR, { recursive: true });
      cb(null, IMAGES_DIR);
    } catch (e: any) {
      cb(e, IMAGES_DIR);
    }
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || "").toLowerCase() || ".jpg";
    const safeExt = [".png", ".jpg", ".jpeg", ".webp"].includes(ext) ? ext : ".jpg";
    const name = `${Date.now()}-${Math.random().toString(16).slice(2)}${safeExt}`;
    cb(null, name);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

function makePublicUrl(req: any, rel: string) {
  const proto = req.headers["x-forwarded-proto"]?.toString() || req.protocol;
  const host = req.headers["x-forwarded-host"]?.toString() || req.get("host");
  return `${proto}://${host}${rel}`;
}

function guessMimeFromExt(filename: string) {
  const ext = path.extname(filename).toLowerCase();
  if (ext === ".png") return "image/png";
  if (ext === ".webp") return "image/webp";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  return "image/*";
}

function parseTags(raw: any): string[] {
  if (raw === undefined || raw === null) return [];
  if (Array.isArray(raw)) {
    return raw.map((x) => String(x).trim()).filter(Boolean);
  }
  const s = String(raw).trim();
  if (!s) return [];

  // allow JSON array
  try {
    const parsed = JSON.parse(s);
    if (Array.isArray(parsed)) {
      return parsed.map((x) => String(x).trim()).filter(Boolean);
    }
  } catch {
    // ignore
  }

  return s
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);
}

async function optimizeImageInPlace(filePath: string) {
  try {
    const ext = path.extname(filePath).toLowerCase();

    let img = sharp(filePath, { failOnError: false }).rotate();
    const meta = await img.metadata();

    // resize down if too large
    const maxW = 2000;
    const maxH = 2000;
    if (meta.width && meta.height && (meta.width > maxW || meta.height > maxH)) {
      img = img.resize({ width: maxW, height: maxH, fit: "inside", withoutEnlargement: true });
    }

    // encode based on ext
    if (ext === ".png") {
      img = img.png({ compressionLevel: 9, palette: true });
    } else if (ext === ".webp") {
      img = img.webp({ quality: 82 });
    } else {
      img = img.jpeg({ quality: 82, mozjpeg: true });
    }

    const tmpPath = `${filePath}.tmp`;
    await img.toFile(tmpPath);
    await fs.rename(tmpPath, filePath);

    const st = await fs.stat(filePath);
    return { width: meta.width ?? null, height: meta.height ?? null, size: st.size };
  } catch {
    // If optimization fails, keep original.
    try {
      const st = await fs.stat(filePath);
      return { width: null, height: null, size: st.size };
    } catch {
      return { width: null, height: null, size: 0 };
    }
  }
}

async function syncDiskImagesToDb() {
  await fs.mkdir(IMAGES_DIR, { recursive: true });
  const names = (await fs.readdir(IMAGES_DIR)).filter((n) => /\.(png|jpe?g|webp)$/i.test(n));
  if (!names.length) return;

  const existing = await prisma.mediaAsset.findMany({
    where: { filename: { in: names } },
    select: { filename: true },
  });
  const seen = new Set(existing.map((x) => x.filename));

  const now = new Date();
  const createRows: any[] = [];

  for (const filename of names) {
    if (seen.has(filename)) continue;
    const p = path.join(IMAGES_DIR, filename);
    const st = await fs.stat(p);
    const createdAt = new Date(st.mtimeMs);
    createRows.push({
      id: undefined,
      kind: "IMAGE",
      filename,
      displayName: filename,
      folder: null,
      tags: [],
      mime: guessMimeFromExt(filename),
      size: st.size,
      width: null,
      height: null,
      createdAt,
      updatedAt: now,
    });
  }

  if (createRows.length) {
    // createMany skips duplicates
    await prisma.mediaAsset.createMany({ data: createRows, skipDuplicates: true });
  }
}

function parseCursor(cursor?: string | null) {
  if (!cursor) return null;
  const [iso, id] = String(cursor).split("|");
  const d = new Date(iso);
  if (!id || Number.isNaN(d.getTime())) return null;
  return { createdAt: d, id };
}

async function ensureFolderExists(name: string | null | undefined) {
  const folderName = (name ?? "").trim();
  if (!folderName) return;
  // This makes folders "real" so the UI can show empty folders too.
  await prisma.mediaFolder.upsert({
    where: { name: folderName },
    update: {},
    create: { name: folderName },
  });
}

type MediaUsage =
  | { kind: "settings"; field: string }
  | { kind: "page"; pageId: string; slug: string; field: string }
  | { kind: "page_section"; pageId: string; slug: string; sectionId: string; sectionType: string }
  | { kind: "product"; productId: string; productSlug: string; productTitle: string; itemId: string; colorName: string; imageId: string };

function includesFilename(val: any, filename: string) {
  if (!val) return false;
  if (typeof val === "string") return val.includes(filename);
  try {
    return JSON.stringify(val).includes(filename);
  } catch {
    return false;
  }
}

async function findUsageByFilename(filename: string): Promise<MediaUsage[]> {
  const usage: MediaUsage[] = [];

  // Settings
  const settings = await prisma.siteSettings.findFirst({
    select: {
      logoUrl: true,
      faviconUrl: true,
      header: true,
      footer: true,
      scriptsHead: true,
      scriptsBody: true,
      customCss: true,
    },
  });
  if (settings) {
    if (includesFilename(settings.logoUrl, filename)) usage.push({ kind: "settings", field: "logoUrl" });
    if (includesFilename(settings.faviconUrl, filename)) usage.push({ kind: "settings", field: "faviconUrl" });
    if (includesFilename(settings.header, filename)) usage.push({ kind: "settings", field: "header" });
    if (includesFilename(settings.footer, filename)) usage.push({ kind: "settings", field: "footer" });
    if (includesFilename(settings.scriptsHead, filename)) usage.push({ kind: "settings", field: "scriptsHead" });
    if (includesFilename(settings.scriptsBody, filename)) usage.push({ kind: "settings", field: "scriptsBody" });
    if (includesFilename(settings.customCss, filename)) usage.push({ kind: "settings", field: "customCss" });
  }

  // Pages + sections
  const sections = await prisma.pageSection.findMany({ select: { id: true, pageId: true, type: true, data: true } });
  const sectionHits = sections.filter((s) => includesFilename(s.data, filename));
  const hitPageIds = new Set(sectionHits.map((s) => s.pageId));

  const pages = await prisma.page.findMany({
    select: { id: true, slug: true, customCss: true, headScripts: true, bodyScripts: true, canonicalUrl: true },
  });

  for (const p of pages) {
    if (includesFilename(p.customCss, filename)) usage.push({ kind: "page", pageId: p.id, slug: p.slug, field: "customCss" });
    if (includesFilename(p.headScripts, filename)) usage.push({ kind: "page", pageId: p.id, slug: p.slug, field: "headScripts" });
    if (includesFilename(p.bodyScripts, filename)) usage.push({ kind: "page", pageId: p.id, slug: p.slug, field: "bodyScripts" });
    if (includesFilename(p.canonicalUrl, filename)) usage.push({ kind: "page", pageId: p.id, slug: p.slug, field: "canonicalUrl" });
  }

  const pageById = new Map(pages.map((p) => [p.id, p] as const));
  for (const s of sectionHits) {
    const p = pageById.get(s.pageId);
    if (!p) continue;
    usage.push({ kind: "page_section", pageId: p.id, slug: p.slug, sectionId: s.id, sectionType: String(s.type) });
  }

  // Products (images table)
  const productImgs = await prisma.productItemImage.findMany({
    where: { url: { contains: filename } },
    select: {
      id: true,
      productItemId: true,
      item: {
        select: {
          id: true,
          colorName: true,
          product: { select: { id: true, slug: true, title: true } },
        },
      },
    },
  });
  for (const img of productImgs) {
    const prod = img.item.product;
    usage.push({
      kind: "product",
      productId: prod.id,
      productSlug: prod.slug,
      productTitle: prod.title,
      itemId: img.item.id,
      colorName: img.item.colorName,
      imageId: img.id,
    });
  }

  // Ensure folder table has any folders currently used by assets.
  if (hitPageIds.size) {
    // no-op, just keeping variable used to avoid lint noise in some configs
  }

  return usage;
}

function makeCursor(createdAt: Date, id: string) {
  return `${createdAt.toISOString()}|${id}`;
}

// GET /admin/uploads/images
// Query:
//  - q: substring search on filename/displayName
//  - folder: exact folder filter
//  - tag: exact tag filter
//  - limit: number (default 60, max 200)
//  - cursor: `${createdAtIso}|${id}`
r.get("/images", async (req, res) => {
  try {
    // Keep DB in sync with disk (best-effort)
    if (!req.query.cursor) {
      await syncDiskImagesToDb();
    }

    const q = (req.query.q?.toString() ?? "").trim();
    const folderRaw = (req.query.folder?.toString() ?? "").trim();
    const tag = (req.query.tag?.toString() ?? "").trim();

    const limitRaw = Number(req.query.limit ?? 60);
    const limit = Math.max(1, Math.min(200, Number.isFinite(limitRaw) ? limitRaw : 60));

    const cursor = parseCursor(req.query.cursor?.toString() ?? null);

    const where: any = {
      kind: "IMAGE",
    };
    if (q) {
      where.OR = [
        { filename: { contains: q, mode: "insensitive" } },
        { displayName: { contains: q, mode: "insensitive" } },
      ];
    }
    if (folderRaw) {
      if (folderRaw === "__unfiled__") where.folder = null;
      else where.folder = folderRaw;
    }
    if (tag) where.tags = { has: tag };

    if (cursor) {
      where.AND = [
        ...(where.AND ?? []),
        {
          OR: [
            { createdAt: { lt: cursor.createdAt } },
            { AND: [{ createdAt: cursor.createdAt }, { id: { lt: cursor.id } }] },
          ],
        },
      ];
    }

    const rows = await prisma.mediaAsset.findMany({
      where,
      orderBy: [{ createdAt: "desc" }, { id: "desc" }],
      take: limit + 1,
    });

    const hasMore = rows.length > limit;
    const page = rows.slice(0, limit);

    const items = page.map((r) => {
      const rel = `/uploads/images/${r.filename}`;
      return {
        id: r.id,
        url: makePublicUrl(req, rel),
        path: rel,
        filename: r.filename,
        displayName: r.displayName,
        folder: r.folder,
        tags: r.tags,
        mimetype: r.mime,
        size: r.size,
        width: r.width,
        height: r.height,
        createdAt: r.createdAt,
        updatedAt: r.updatedAt,
      };
    });

    const nextCursor = hasMore && page.length ? makeCursor(page[page.length - 1]!.createdAt, page[page.length - 1]!.id) : null;

    return res.json({ items, nextCursor });
  } catch (e: any) {
    return res.status(500).json({ error: "LIST_UPLOADS_FAILED", message: e?.message ?? String(e) });
  }
});

// GET /admin/uploads/images/folders
r.get("/images/folders", async (_req, res) => {
  try {
    // Ensure any folders used by assets exist in the folder table
    type FolderCountRow = { folder: string | null; _count: { id: number } };
    const countsRows = (await prisma.mediaAsset.groupBy({
      by: ["folder"],
      where: { kind: "IMAGE" },
      _count: { id: true },
      orderBy: { _count: { id: "desc" } },
    })) as unknown as FolderCountRow[];

    const names = countsRows
      .map((r) => r.folder)
      .filter((x): x is string => typeof x === "string" && x.trim().length > 0)
      .map((x) => x.trim());
    for (const n of names) {
      await ensureFolderExists(n);
    }

    const countMap = new Map<string, number>();
    for (const row of countsRows) {
      if (row.folder) countMap.set(row.folder, row._count.id);
    }

    const folderRows = await prisma.mediaFolder.findMany({ orderBy: { name: "asc" } });
    const folders = folderRows.map((f) => ({ id: f.id, name: f.name, folder: f.name, count: countMap.get(f.name) ?? 0 }));

    const unfiledCount = await prisma.mediaAsset.count({ where: { kind: "IMAGE", folder: null } });
    res.json({ folders, unfiledCount });
  } catch (e: any) {
    res.status(500).json({ error: "LIST_FOLDERS_FAILED", message: e?.message ?? String(e) });
  }
});

// POST /admin/uploads/images/folders  { name }
r.post("/images/folders", async (req, res) => {
  try {
    const name = String(req.body?.name ?? "").trim();
    if (!name) return res.status(400).json({ error: "INVALID_NAME" });
    const folder = await prisma.mediaFolder.create({ data: { name } });
    return res.status(201).json({ folder: { id: folder.id, name: folder.name } });
  } catch (e: any) {
    // unique constraint
    if (String(e?.code || "").includes("P2002")) {
      return res.status(409).json({ error: "FOLDER_EXISTS" });
    }
    return res.status(400).json({ error: "CREATE_FOLDER_FAILED", message: e?.message ?? String(e) });
  }
});

// PATCH /admin/uploads/images/folders/:id  { name }
r.patch("/images/folders/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const name = String(req.body?.name ?? "").trim();
    if (!name) return res.status(400).json({ error: "INVALID_NAME" });

    const current = await prisma.mediaFolder.findUnique({ where: { id } });
    if (!current) return res.status(404).json({ error: "NOT_FOUND" });

    const updated = await prisma.$transaction(async (tx) => {
      const f = await tx.mediaFolder.update({ where: { id }, data: { name } });
      await tx.mediaAsset.updateMany({ where: { kind: "IMAGE", folder: current.name }, data: { folder: name } });
      return f;
    });
    return res.json({ folder: { id: updated.id, name: updated.name } });
  } catch (e: any) {
    if (String(e?.code || "").includes("P2002")) {
      return res.status(409).json({ error: "FOLDER_EXISTS" });
    }
    return res.status(400).json({ error: "RENAME_FOLDER_FAILED", message: e?.message ?? String(e) });
  }
});

// DELETE /admin/uploads/images/folders/:id
r.delete("/images/folders/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const folder = await prisma.mediaFolder.findUnique({ where: { id } });
    if (!folder) return res.status(404).json({ error: "NOT_FOUND" });
    const count = await prisma.mediaAsset.count({ where: { kind: "IMAGE", folder: folder.name } });
    if (count > 0) {
      return res.status(409).json({ error: "FOLDER_NOT_EMPTY", count });
    }
    await prisma.mediaFolder.delete({ where: { id } });
    return res.json({ ok: true });
  } catch (e: any) {
    return res.status(400).json({ error: "DELETE_FOLDER_FAILED", message: e?.message ?? String(e) });
  }
});

// GET /admin/uploads/images/tags
r.get("/images/tags", async (_req, res) => {
  try {
    // PostgreSQL: unnest tags
    const rows: Array<{ tag: string; count: bigint }> = await prisma.$queryRaw`
      SELECT unnest("tags") AS tag, count(*) AS count
      FROM "MediaAsset"
      WHERE "kind" = 'IMAGE'
      GROUP BY tag
      ORDER BY count DESC;
    `;

    const tags = rows.map((r) => ({ tag: r.tag, count: Number(r.count) }));
    res.json({ tags });
  } catch (e: any) {
    res.status(500).json({ error: "LIST_TAGS_FAILED", message: e?.message ?? String(e) });
  }
});

// PATCH /admin/uploads/images/:id
r.patch("/images/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const displayName = req.body?.displayName !== undefined ? String(req.body.displayName).trim() : undefined;
    const folder = req.body?.folder !== undefined ? String(req.body.folder).trim() || null : undefined;
    const tags = req.body?.tags !== undefined ? parseTags(req.body.tags) : undefined;

    if (folder !== undefined) {
      await ensureFolderExists(folder);
    }

    const data: any = {};
    if (displayName !== undefined) data.displayName = displayName || null;
    if (folder !== undefined) data.folder = folder;
    if (tags !== undefined) data.tags = tags;

    const updated = await prisma.mediaAsset.update({ where: { id }, data });

    const rel = `/uploads/images/${updated.filename}`;
    res.json({
      id: updated.id,
      url: makePublicUrl(req, rel),
      path: rel,
      filename: updated.filename,
      displayName: updated.displayName,
      folder: updated.folder,
      tags: updated.tags,
      mimetype: updated.mime,
      size: updated.size,
      width: updated.width,
      height: updated.height,
      createdAt: updated.createdAt,
      updatedAt: updated.updatedAt,
    });
  } catch (e: any) {
    res.status(400).json({ error: "UPDATE_MEDIA_FAILED", message: e?.message ?? String(e) });
  }
});

// PATCH /admin/uploads/images/bulk
r.patch("/images/bulk", async (req, res) => {
  try {
    const ids = Array.isArray(req.body?.ids) ? req.body.ids.map((x: any) => String(x)) : [];
    if (!ids.length) return res.status(400).json({ error: "NO_IDS" });

    const folder = req.body?.folder !== undefined ? String(req.body.folder).trim() || null : undefined;
    const setTags = req.body?.setTags !== undefined ? parseTags(req.body.setTags) : undefined;
    const addTags = req.body?.addTags !== undefined ? parseTags(req.body.addTags) : undefined;
    const removeTags = req.body?.removeTags !== undefined ? parseTags(req.body.removeTags) : undefined;

    if (folder !== undefined) {
      await ensureFolderExists(folder);
    }

    if (folder !== undefined || setTags !== undefined) {
      await prisma.mediaAsset.updateMany({
        where: { id: { in: ids }, kind: "IMAGE" },
        data: {
          ...(folder !== undefined ? { folder } : {}),
          ...(setTags !== undefined ? { tags: setTags } : {}),
        },
      });
    }

    if ((addTags && addTags.length) || (removeTags && removeTags.length)) {
      const rows = await prisma.mediaAsset.findMany({ where: { id: { in: ids }, kind: "IMAGE" }, select: { id: true, tags: true } });
      for (const row of rows) {
        const current = row.tags ?? [];
        const next = Array.from(
          new Set([
            ...current,
            ...(addTags ?? []),
          ])
        ).filter((t) => !(removeTags ?? []).includes(t));
        await prisma.mediaAsset.update({ where: { id: row.id }, data: { tags: next } });
      }
    }

    return res.json({ ok: true });
  } catch (e: any) {
    return res.status(400).json({ error: "BULK_UPDATE_FAILED", message: e?.message ?? String(e) });
  }
});

// DELETE /admin/uploads/images/bulk
r.delete("/images/bulk", async (req, res) => {
  try {
    const ids = Array.isArray(req.body?.ids) ? req.body.ids.map((x: any) => String(x)) : [];
    if (!ids.length) return res.status(400).json({ error: "NO_IDS" });

    const rows = await prisma.mediaAsset.findMany({ where: { id: { in: ids }, kind: "IMAGE" }, select: { id: true, filename: true } });
    const usageById: Record<string, MediaUsage[]> = {};

    for (const row of rows) {
      const u = await findUsageByFilename(row.filename);
      if (u.length) usageById[row.id] = u;
    }
    if (Object.keys(usageById).length) {
      return res.status(409).json({ error: "MEDIA_IN_USE", usageById });
    }

    // delete files from disk best-effort
    for (const row of rows) {
      const fp = path.join(IMAGES_DIR, row.filename);
      try {
        await fs.unlink(fp);
      } catch {
        // ignore
      }
    }

    await prisma.mediaAsset.deleteMany({ where: { id: { in: ids } } });
    return res.json({ ok: true });
  } catch (e: any) {
    return res.status(400).json({ error: "BULK_DELETE_FAILED", message: e?.message ?? String(e) });
  }
});

// GET /admin/uploads/images/:id/usage
r.get("/images/:id/usage", async (req, res) => {
  try {
    const id = req.params.id;
    const row = await prisma.mediaAsset.findUnique({ where: { id }, select: { filename: true } });
    if (!row) return res.status(404).json({ error: "NOT_FOUND" });
    const usage = await findUsageByFilename(row.filename);
    return res.json({ filename: row.filename, usage });
  } catch (e: any) {
    return res.status(400).json({ error: "USAGE_FAILED", message: e?.message ?? String(e) });
  }
});

// DELETE /admin/uploads/images/:id
r.delete("/images/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const row = await prisma.mediaAsset.findUnique({ where: { id } });
    if (!row) return res.status(404).json({ error: "NOT_FOUND" });

    const usage = await findUsageByFilename(row.filename);
    if (usage.length) {
      return res.status(409).json({ error: "MEDIA_IN_USE", usage });
    }

    const fp = path.join(IMAGES_DIR, row.filename);
    try {
      await fs.unlink(fp);
    } catch {
      // ignore
    }

    await prisma.mediaAsset.delete({ where: { id } });
    res.json({ ok: true });
  } catch (e: any) {
    res.status(400).json({ error: "DELETE_MEDIA_FAILED", message: e?.message ?? String(e) });
  }
});

// POST /admin/uploads/images
// Supports BOTH:
//  - single file field name: `file`
//  - multiple files field name: `files`
// Optional multipart fields:
//  - folder: string
//  - tags: comma-separated string OR JSON array
// Returns: { files: UploadedFile[] }
const imagesUpload = upload.fields([
  { name: "file", maxCount: 1 },
  { name: "files", maxCount: 20 },
]);

r.post("/images", (req, res) => {
  imagesUpload(req as any, res as any, async (err: any) => {
    if (err) {
      const code = err?.code;
      if (code === "LIMIT_FILE_SIZE") {
        return res.status(413).json({ error: "FILE_TOO_LARGE", message: "Max file size is 10MB" });
      }
      if (code === "LIMIT_UNEXPECTED_FILE") {
        return res.status(400).json({ error: "UNEXPECTED_FIELD", message: "Expected field name: file or files" });
      }
      return res.status(400).json({ error: "UPLOAD_FAILED", message: err?.message ?? String(err) });
    }

    try {
      const files: any[] = [];
      const f: any = (req as any).files;
      if (f?.file?.[0]) files.push(f.file[0]);
      if (Array.isArray(f?.files)) files.push(...f.files);

      if (!files.length) {
        return res.status(400).json({ error: "NO_FILE" });
      }

      const folder = (req.body?.folder ? String(req.body.folder).trim() : "") || null;
      const tags = parseTags(req.body?.tags);

      await ensureFolderExists(folder);

      const out: any[] = [];

      for (const file of files) {
        const fullPath = path.join(IMAGES_DIR, file.filename);

        const opt = await optimizeImageInPlace(fullPath);

        const created = await prisma.mediaAsset.create({
          data: {
            kind: "IMAGE",
            filename: file.filename,
            displayName: file.originalname || file.filename,
            folder,
            tags,
            mime: file.mimetype || guessMimeFromExt(file.filename),
            size: opt.size || file.size,
            width: opt.width,
            height: opt.height,
          },
        });

        const rel = `/uploads/images/${file.filename}`;
        out.push({
          id: created.id,
          url: makePublicUrl(req, rel),
          path: rel,
          filename: created.filename,
          displayName: created.displayName,
          folder: created.folder,
          tags: created.tags,
          mimetype: created.mime,
          size: created.size,
          width: created.width,
          height: created.height,
          createdAt: created.createdAt,
          updatedAt: created.updatedAt,
        });
      }

      return res.status(201).json({ files: out });
    } catch (e: any) {
      return res.status(500).json({ error: "UPLOAD_FAILED", message: e?.message ?? String(e) });
    }
  });
});

export default r;