export type ThemePresetId =
  | "estabrak_soft_gold"
  | "luxury_gold"
  | "clean_tech"
  | "street_dark"
  | "soft_pastel"
  | "earth_minimal"
  | "ocean_mist"
  | "desert_sand"
  | "plum_night"
  | (string & {});

export type ThemeVars = Record<string, string>;

export type ThemePreset = {
  id: ThemePresetId;
  name: string;
  accentStops: [string, string, string];
  light: ThemeVars;
  dark: ThemeVars;
};

export const THEME_PRESETS: ThemePreset[] = [
  {
    id: "estabrak_soft_gold",
    name: "Estabrak Soft (Teal + Gold)",
    accentStops: ["#E6D8A8", "#C6A75E", "#6FA6A1"],
    light: {
      "--bg": "#F7F4E9",
      "--surface": "#FFFFFF",
      "--surface-2": "#EFEADB",
      "--border": "#E2DBC8",
      "--text": "#1A1A1A",
      "--muted": "#5A5A5A",
      "--accent": "#6FA6A1",
      "--accent-hover": "#5B918C",
      "--accent-soft": "#C6A75E",
    },
    dark: {
      "--bg": "#0B0B0B",
      "--surface": "#111111",
      "--surface-2": "#1A1A1A",
      "--border": "#2A2A2A",
      "--text": "#F7F4E9",
      "--muted": "#C9C2B2",
      "--accent": "#6FA6A1",
      "--accent-hover": "#C6A75E",
      "--accent-soft": "#E6D8A8",
    },
  },
  {
    id: "luxury_gold",
    name: "Luxury Paper (Black + Gold)",
    accentStops: ["#E6D8A8", "#C6A75E", "#A88C3E"],
    light: {
      "--bg": "#F7F4E9",
      "--surface": "#FFFFFF",
      "--surface-2": "#EFEADB",
      "--border": "#E2DBC8",
      "--text": "#0B0B0B",
      "--muted": "#3A3A3A",
      "--accent": "#C6A75E",
      "--accent-hover": "#A88C3E",
      "--accent-soft": "#E6D8A8",
    },
    dark: {
      "--bg": "#0B0B0B",
      "--surface": "#111111",
      "--surface-2": "#1A1A1A",
      "--border": "#2A2A2A",
      "--text": "#F7F4E9",
      "--muted": "#C9C2B2",
      "--accent": "#C6A75E",
      "--accent-hover": "#E6D8A8",
      "--accent-soft": "#A88C3E",
    },
  },
  {
    id: "clean_tech",
    name: "Clean Tech (Blue)",
    accentStops: ["#2563EB", "#60A5FA", "#EEF3FF"],
    light: {
      "--bg": "#F6F8FC",
      "--surface": "#FFFFFF",
      "--surface-2": "#EEF3FF",
      "--border": "#D9E2F2",
      "--text": "#0F172A",
      "--muted": "#475569",
      "--accent": "#2563EB",
      "--accent-hover": "#1D4ED8",
      "--accent-soft": "#93C5FD",
    },
    dark: {
      "--bg": "#0B1020",
      "--surface": "#0F172A",
      "--surface-2": "#111C35",
      "--border": "#223152",
      "--text": "#E5E7EB",
      "--muted": "#A1A1AA",
      "--accent": "#60A5FA",
      "--accent-hover": "#93C5FD",
      "--accent-soft": "#2563EB",
    },
  },
  {
    id: "street_dark",
    name: "Street Dark (Neon Lime)",
    accentStops: ["#A3E635", "#84CC16", "#D9F99D"],
    light: {
      "--bg": "#F3F4F6",
      "--surface": "#FFFFFF",
      "--surface-2": "#E5E7EB",
      "--border": "#D1D5DB",
      "--text": "#0B0F14",
      "--muted": "#374151",
      "--accent": "#84CC16",
      "--accent-hover": "#65A30D",
      "--accent-soft": "#D9F99D",
    },
    dark: {
      "--bg": "#0B0F14",
      "--surface": "#101826",
      "--surface-2": "#0E1623",
      "--border": "#1F2A3A",
      "--text": "#E5E7EB",
      "--muted": "#9CA3AF",
      "--accent": "#A3E635",
      "--accent-hover": "#84CC16",
      "--accent-soft": "#D9F99D",
    },
  },
  {
    id: "soft_pastel",
    name: "Soft Pastel (Rose)",
    accentStops: ["#FB7185", "#FDBA74", "#FFF7F0"],
    light: {
      "--bg": "#FFF7F0",
      "--surface": "#FFFFFF",
      "--surface-2": "#FFE8E2",
      "--border": "#F3D6CF",
      "--text": "#1F2937",
      "--muted": "#6B7280",
      "--accent": "#FB7185",
      "--accent-hover": "#E11D48",
      "--accent-soft": "#FECDD3",
    },
    dark: {
      "--bg": "#111111",
      "--surface": "#151515",
      "--surface-2": "#1F1F1F",
      "--border": "#2A2A2A",
      "--text": "#FFF7F0",
      "--muted": "#D1D5DB",
      "--accent": "#FB7185",
      "--accent-hover": "#FECDD3",
      "--accent-soft": "#E11D48",
    },
  },
  {
    id: "earth_minimal",
    name: "Earth Minimal (Forest)",
    accentStops: ["#166534", "#86EFAC", "#F4F1EA"],
    light: {
      "--bg": "#F4F1EA",
      "--surface": "#FFFFFF",
      "--surface-2": "#E9E4D7",
      "--border": "#D8D0BF",
      "--text": "#1B1F1D",
      "--muted": "#4B5563",
      "--accent": "#166534",
      "--accent-hover": "#14532D",
      "--accent-soft": "#86EFAC",
    },
    dark: {
      "--bg": "#0D1411",
      "--surface": "#111C17",
      "--surface-2": "#15231D",
      "--border": "#2A3A33",
      "--text": "#F4F1EA",
      "--muted": "#C9C2B2",
      "--accent": "#86EFAC",
      "--accent-hover": "#BBF7D0",
      "--accent-soft": "#166534",
    },
  },
  {
    id: "ocean_mist",
    name: "Ocean Mist (Sky)",
    accentStops: ["#7DD3FC", "#0EA5E9", "#0284C7"],
    light: {
      "--bg": "#F2FAFF",
      "--surface": "#FFFFFF",
      "--surface-2": "#E3F1FA",
      "--border": "#CFE3EF",
      "--text": "#0F172A",
      "--muted": "#475569",
      "--accent": "#0EA5E9",
      "--accent-hover": "#0284C7",
      "--accent-soft": "#7DD3FC",
    },
    dark: {
      "--bg": "#0B1420",
      "--surface": "#0F1B2E",
      "--surface-2": "#12233A",
      "--border": "#1F324D",
      "--text": "#E2E8F0",
      "--muted": "#94A3B8",
      "--accent": "#38BDF8",
      "--accent-hover": "#0EA5E9",
      "--accent-soft": "#7DD3FC",
    },
  },
  {
    id: "desert_sand",
    name: "Desert Sand (Amber)",
    accentStops: ["#F2C18D", "#D97706", "#B45309"],
    light: {
      "--bg": "#FFF6E9",
      "--surface": "#FFFFFF",
      "--surface-2": "#F7E9D4",
      "--border": "#E9D6BC",
      "--text": "#3B2F2A",
      "--muted": "#6B5B52",
      "--accent": "#D97706",
      "--accent-hover": "#B45309",
      "--accent-soft": "#F2C18D",
    },
    dark: {
      "--bg": "#1A120D",
      "--surface": "#221812",
      "--surface-2": "#2A1F18",
      "--border": "#3B2A20",
      "--text": "#FCEFE0",
      "--muted": "#D5C4B5",
      "--accent": "#F59E0B",
      "--accent-hover": "#D97706",
      "--accent-soft": "#F2C18D",
    },
  },
  {
    id: "plum_night",
    name: "Plum Night (Purple)",
    accentStops: ["#E9D5FF", "#A855F7", "#7E22CE"],
    light: {
      "--bg": "#F8F5FF",
      "--surface": "#FFFFFF",
      "--surface-2": "#EEE7F7",
      "--border": "#DDD0EE",
      "--text": "#1C102A",
      "--muted": "#5B4B70",
      "--accent": "#A855F7",
      "--accent-hover": "#7E22CE",
      "--accent-soft": "#E9D5FF",
    },
    dark: {
      "--bg": "#0F0B14",
      "--surface": "#15111B",
      "--surface-2": "#1D1626",
      "--border": "#2D2338",
      "--text": "#F5F3FF",
      "--muted": "#C4BBD9",
      "--accent": "#C084FC",
      "--accent-hover": "#A855F7",
      "--accent-soft": "#E9D5FF",
    },
  },
];

export function getThemePreset(id?: string | null) {
  return THEME_PRESETS.find((p) => p.id === id) ?? THEME_PRESETS[0];
}
