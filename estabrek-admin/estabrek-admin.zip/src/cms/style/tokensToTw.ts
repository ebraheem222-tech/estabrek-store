import type { TwTokens } from "./tokens";
import {
  bgMap,
  displayMap,
  positionMap,
  radiusMap,
  shadowMap,
  hoverMap,
  animMap,
  delayMap,
  durationMap,
  paddingMap,
  gapMap,
  textSizeMap,
  textAlignMap,
  fontWeightMap,
  textColorMap,
  maxWMap,
  flexDirMap,
  flexWrapMap,
  justifyMap,
  itemsMap,
  gridColsMap,
  gridRowsMap,
  justifyItemsMap,
  placeItemsMap,
} from "./twMaps";

export function resolveCustomColor(value?: string): string | undefined {
  if (!value || typeof value !== "string") return undefined;
  const v = value.trim();
  if (!v) return undefined;
  if (/^#([0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(v)) return v;
  if (/^(rgb|rgba|hsl|hsla)\(/i.test(v)) return v;
  if (/^var\\(--.+\\)$/.test(v)) return v;
  if (v === "transparent" || v === "currentColor") return v;
  return undefined;
}

export function tokensToClassName(tokens?: TwTokens): string {
  if (!tokens) return "";
  const parts: string[] = [];

  // layout
  if (tokens.layout?.display) parts.push(displayMap[tokens.layout.display]);

  // advanced flex/grid settings
  const display = tokens.layout?.display;
  if (display === "flex" || display === "inline-flex") {
    const fx = tokens.layout?.flex;
    if (fx?.dir) parts.push(flexDirMap[fx.dir]);
    if (fx?.wrap) parts.push(flexWrapMap[fx.wrap]);
    if (fx?.justify) parts.push(justifyMap[fx.justify]);
    if (fx?.items) parts.push(itemsMap[fx.items]);
  }

  if (display === "grid") {
    const gr = tokens.layout?.grid;
    if (gr?.cols) parts.push(gridColsMap[gr.cols]);
    if (gr?.rows) parts.push(gridRowsMap[gr.rows]);
    if (gr?.justifyItems) parts.push(justifyItemsMap[gr.justifyItems]);
    if (gr?.placeItems) parts.push(placeItemsMap[gr.placeItems]);
  }

  if (tokens.layout?.position) parts.push(positionMap[tokens.layout.position]);
  if (tokens.layout?.zIndex) parts.push(tokens.layout.zIndex === "auto" ? "z-auto" : `z-${tokens.layout.zIndex}`);

  // size
  if (tokens.size?.maxW) parts.push(maxWMap[tokens.size.maxW]);

  // spacing
  if (tokens.spacing?.padding) parts.push(paddingMap[tokens.spacing.padding]);
  if (tokens.spacing?.gap) parts.push(gapMap[tokens.spacing.gap]);

  // typography
  if (tokens.typography?.size) parts.push(textSizeMap[tokens.typography.size]);
  if (tokens.typography?.align) parts.push(textAlignMap[tokens.typography.align]);
  if (tokens.typography?.weight) parts.push(fontWeightMap[tokens.typography.weight]);
  if (tokens.typography?.color) parts.push(textColorMap[tokens.typography.color]);

  // style
  if (tokens.style?.bg) parts.push(bgMap[tokens.style.bg]);
  if (tokens.style?.radius) parts.push(radiusMap[tokens.style.radius]);
  if (tokens.style?.shadow) parts.push(shadowMap[tokens.style.shadow]);

  // state
  if (tokens.state?.hover) parts.push(hoverMap[tokens.state.hover]);

  // motion
  if (tokens.motion?.anim) parts.push(animMap[tokens.motion.anim]);
  if (tokens.motion?.delay !== undefined) parts.push(delayMap[tokens.motion.delay]);
  if (tokens.motion?.duration) parts.push(durationMap[tokens.motion.duration]);

  // custom colors (inline vars)
  const customBg = resolveCustomColor(tokens.style?.bgColor ?? tokens.style?.bg);
  const customText = resolveCustomColor(tokens.typography?.colorCustom ?? tokens.typography?.color);
  if (customBg) parts.push("cms-inline-bg");
  if (customText) parts.push("cms-inline-text");

  return parts.filter(Boolean).join(" ").trim();
}
