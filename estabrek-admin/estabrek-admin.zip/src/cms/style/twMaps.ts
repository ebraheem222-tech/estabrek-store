import type {
  BgPreset,
  DisplayPreset,
  PositionPreset,
  RadiusPreset,
  ShadowPreset,
  HoverPreset,
  AnimPreset,
  DelayPreset,
  DurationPreset,
  PaddingPreset,
  GapPreset,
  TextSizePreset,
  TextAlignPreset,
  FontWeightPreset,
  TextColorPreset,
  MaxWidthPreset,
  FlexDirPreset,
  FlexWrapPreset,
  JustifyPreset,
  ItemsPreset,
  GridColsPreset,
  GridRowsPreset,
  JustifyItemsPreset,
  PlaceItemsPreset,
} from "./tokens";

// Layout
export const displayMap: Record<DisplayPreset, string> = {
  "block": "block",
  "inline-block": "inline-block",
  "inline-flex": "inline-flex",
  "flex": "flex",
  "grid": "grid",
};

export const positionMap: Record<PositionPreset, string> = {
  static: "static",
  relative: "relative",
  absolute: "absolute",
  sticky: "sticky top-0",
};

// Flex presets
export const flexDirMap: Record<FlexDirPreset, string> = {
  row: "flex-row",
  col: "flex-col",
};

export const flexWrapMap: Record<FlexWrapPreset, string> = {
  nowrap: "flex-nowrap",
  wrap: "flex-wrap",
};

export const justifyMap: Record<JustifyPreset, string> = {
  start: "justify-start",
  center: "justify-center",
  end: "justify-end",
  between: "justify-between",
  around: "justify-around",
  evenly: "justify-evenly",
};

export const itemsMap: Record<ItemsPreset, string> = {
  start: "items-start",
  center: "items-center",
  end: "items-end",
  stretch: "items-stretch",
  baseline: "items-baseline",
};

// Grid presets
export const gridColsMap: Record<GridColsPreset, string> = {
  1: "grid-cols-1",
  2: "grid-cols-2",
  3: "grid-cols-3",
  4: "grid-cols-4",
  5: "grid-cols-5",
  6: "grid-cols-6",
};

export const gridRowsMap: Record<GridRowsPreset, string> = {
  auto: "auto-rows-auto",
  1: "grid-rows-1",
  2: "grid-rows-2",
  3: "grid-rows-3",
  4: "grid-rows-4",
  5: "grid-rows-5",
  6: "grid-rows-6",
};

export const justifyItemsMap: Record<JustifyItemsPreset, string> = {
  start: "justify-items-start",
  center: "justify-items-center",
  end: "justify-items-end",
  stretch: "justify-items-stretch",
};

export const placeItemsMap: Record<PlaceItemsPreset, string> = {
  start: "place-items-start",
  center: "place-items-center",
  end: "place-items-end",
  stretch: "place-items-stretch",
};

// Radius / shadow
export const radiusMap: Record<RadiusPreset, string> = {
  none: "rounded-none",
  md: "rounded-md",
  lg: "rounded-lg",
  xl: "rounded-xl",
  "2xl": "rounded-2xl",
  full: "rounded-full",
};

export const shadowMap: Record<ShadowPreset, string> = {
  none: "shadow-none",
  sm: "shadow-sm",
  md: "shadow-md",
  lg: "shadow-lg",
  xl: "shadow-xl",
};

// Background presets (Tailwind-only)
export const bgMap: Record<BgPreset, string> = {
  none: "",
  "solid-surface": "bg-white dark:bg-black/20",
  "solid-muted": "bg-black/5 dark:bg-white/5",
  "solid-primary": "bg-black text-white dark:bg-white dark:text-black",
  "solid-secondary": "bg-white text-black border border-black/10 dark:bg-white/10 dark:text-white dark:border-white/15",
  "gradient-sunset": "bg-gradient-to-r from-rose-500/90 via-orange-500/80 to-amber-400/80 text-white",
  "gradient-ocean": "bg-gradient-to-r from-cyan-500/80 via-sky-500/80 to-indigo-500/80 text-white",
  "gradient-neon": "bg-gradient-to-r from-fuchsia-500/80 via-purple-500/80 to-blue-500/80 text-white",
  "glass-sm": "bg-white/5 backdrop-blur-sm border border-white/10",
  "glass-md": "bg-white/10 backdrop-blur-md border border-white/10",
  "glass-lg": "bg-white/15 backdrop-blur-lg border border-white/10",
};

// State
export const hoverMap: Record<HoverPreset, string> = {
  none: "",
  lift: "transition-transform hover:-translate-y-0.5",
  glow: "transition-shadow hover:shadow-xl",
  underline: "hover:underline underline-offset-4",
  scale: "transition-transform hover:scale-[1.02]",
};

// Motion
export const animMap: Record<AnimPreset, string> = {
  none: "",
  "fade-up": "animate-cms-fade-up",
  "zoom-in": "animate-cms-zoom-in",
  "slide-up": "animate-cms-slide-up",
  "scale-in": "animate-cms-scale-in",
};

export const delayMap: Record<DelayPreset, string> = {
  0: "delay-0",
  75: "delay-75",
  100: "delay-100",
  150: "delay-150",
  200: "delay-200",
  300: "delay-300",
  500: "delay-500",
  700: "delay-700",
  1000: "delay-1000",
};

export const durationMap: Record<DurationPreset, string> = {
  150: "duration-150",
  200: "duration-200",
  300: "duration-300",
  400: "duration-400",
  600: "duration-600",
  800: "duration-800",
  1000: "duration-1000",
};

// Spacing
export const paddingMap: Record<PaddingPreset, string> = {
  none: "p-0",
  xs: "p-2",
  sm: "p-3",
  md: "p-4",
  lg: "p-6",
  xl: "p-8",
};

export const gapMap: Record<GapPreset, string> = {
  none: "gap-0",
  xs: "gap-2",
  sm: "gap-3",
  md: "gap-4",
  lg: "gap-6",
  xl: "gap-8",
};

// Typography
export const textSizeMap: Record<TextSizePreset, string> = {
  xs: "text-xs",
  sm: "text-sm",
  base: "text-base",
  lg: "text-lg",
  xl: "text-xl",
  "2xl": "text-2xl",
  "3xl": "text-3xl",
  "4xl": "text-4xl",
};

export const textAlignMap: Record<TextAlignPreset, string> = {
  left: "text-left",
  center: "text-center",
  right: "text-right",
};

export const fontWeightMap: Record<FontWeightPreset, string> = {
  normal: "font-normal",
  medium: "font-medium",
  semibold: "font-semibold",
  bold: "font-bold",
};

export const textColorMap: Record<TextColorPreset, string> = {
  default: "text-black dark:text-white",
  muted: "text-black/60 dark:text-white/70",
  primary: "text-accent-500",
  onPrimary: "text-white",
  danger: "text-red-600 dark:text-red-400",
};

// Sizing
export const maxWMap: Record<MaxWidthPreset, string> = {
  none: "max-w-none",
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-xl",
  "2xl": "max-w-2xl",
  prose: "prose dark:prose-invert",
};
