export const DISPLAY_PRESETS = ["block","inline-block","inline-flex","flex","grid"] as const;
export type DisplayPreset = typeof DISPLAY_PRESETS[number];

export const POSITION_PRESETS = ["static","relative","absolute","sticky"] as const;
export type PositionPreset = typeof POSITION_PRESETS[number];

// Flex / Grid (advanced layout presets)
export const FLEX_DIR_PRESETS = ["row", "col"] as const;
export type FlexDirPreset = typeof FLEX_DIR_PRESETS[number];

export const FLEX_WRAP_PRESETS = ["nowrap", "wrap"] as const;
export type FlexWrapPreset = typeof FLEX_WRAP_PRESETS[number];

export const JUSTIFY_PRESETS = ["start", "center", "end", "between", "around", "evenly"] as const;
export type JustifyPreset = typeof JUSTIFY_PRESETS[number];

export const ITEMS_PRESETS = ["start", "center", "end", "stretch", "baseline"] as const;
export type ItemsPreset = typeof ITEMS_PRESETS[number];

export const GRID_COLS_PRESETS = [1, 2, 3, 4, 5, 6] as const;
export type GridColsPreset = typeof GRID_COLS_PRESETS[number];

export const GRID_ROWS_PRESETS = ["auto", 1, 2, 3, 4, 5, 6] as const;
export type GridRowsPreset = typeof GRID_ROWS_PRESETS[number];

export const JUSTIFY_ITEMS_PRESETS = ["start", "center", "end", "stretch"] as const;
export type JustifyItemsPreset = typeof JUSTIFY_ITEMS_PRESETS[number];

export const PLACE_ITEMS_PRESETS = ["start", "center", "end", "stretch"] as const;
export type PlaceItemsPreset = typeof PLACE_ITEMS_PRESETS[number];

export const RADIUS_PRESETS = ["none","md","lg","xl","2xl","full"] as const;
export type RadiusPreset = typeof RADIUS_PRESETS[number];

export const SHADOW_PRESETS = ["none","sm","md","lg","xl"] as const;
export type ShadowPreset = typeof SHADOW_PRESETS[number];

export const BG_PRESETS = [
  "none",
  "solid-surface",
  "solid-muted",
  "solid-primary",
  "solid-secondary",
  "gradient-sunset",
  "gradient-ocean",
  "gradient-neon",
  "glass-sm",
  "glass-md",
  "glass-lg",
] as const;
export type BgPreset = typeof BG_PRESETS[number];

export const HOVER_PRESETS = ["none","lift","glow","underline","scale"] as const;
export type HoverPreset = typeof HOVER_PRESETS[number];

export const ANIM_PRESETS = ["none","fade-up","zoom-in","slide-up","scale-in"] as const;
export type AnimPreset = typeof ANIM_PRESETS[number];

export const DELAY_PRESETS = [0,75,100,150,200,300,500,700,1000] as const;
export type DelayPreset = typeof DELAY_PRESETS[number];

export const DURATION_PRESETS = [150,200,300,400,600,800,1000] as const;
export type DurationPreset = typeof DURATION_PRESETS[number];

export const PADDING_PRESETS = ["none","xs","sm","md","lg","xl"] as const;
export type PaddingPreset = typeof PADDING_PRESETS[number];

export const GAP_PRESETS = ["none","xs","sm","md","lg","xl"] as const;
export type GapPreset = typeof GAP_PRESETS[number];

export const TEXT_SIZE_PRESETS = ["xs","sm","base","lg","xl","2xl","3xl","4xl"] as const;
export type TextSizePreset = typeof TEXT_SIZE_PRESETS[number];

export const TEXT_ALIGN_PRESETS = ["left","center","right"] as const;
export type TextAlignPreset = typeof TEXT_ALIGN_PRESETS[number];

export const FONT_WEIGHT_PRESETS = ["normal","medium","semibold","bold"] as const;
export type FontWeightPreset = typeof FONT_WEIGHT_PRESETS[number];

export const TEXT_COLOR_PRESETS = ["default","muted","primary","onPrimary","danger"] as const;
export type TextColorPreset = typeof TEXT_COLOR_PRESETS[number];

export const MAX_W_PRESETS = ["none","sm","md","lg","xl","2xl","prose"] as const;
export type MaxWidthPreset = typeof MAX_W_PRESETS[number];



export const DECOR_SHAPE_PRESETS = ["none","wave","wave2","diagonal","curve","zigzag","blob","blob2"] as const;
export type DecorShapePreset = typeof DECOR_SHAPE_PRESETS[number];

export const DECOR_PLACEMENT_PRESETS = ["top","bottom","left","right"] as const;
export type DecorPlacementPreset = typeof DECOR_PLACEMENT_PRESETS[number];

export const DECOR_SIZE_PRESETS = ["xs","sm","md","lg","xl"] as const;
export type DecorSizePreset = typeof DECOR_SIZE_PRESETS[number];

export const DECOR_COLOR_PRESETS = ["muted","white","black","sunset","ocean","neon","primary"] as const;
export type DecorColorPreset = typeof DECOR_COLOR_PRESETS[number];

export const DECOR_FILL_PRESETS = ["solid","gradient","glass"] as const;
export type DecorFillPreset = typeof DECOR_FILL_PRESETS[number];

export const DECOR_BLUR_PRESETS = ["0","sm","md"] as const;
export type DecorBlurPreset = typeof DECOR_BLUR_PRESETS[number];

export type DecorLayer = {
  shape?: DecorShapePreset;
  placement?: DecorPlacementPreset;
  size?: DecorSizePreset;
  fill?: DecorFillPreset;
  color?: DecorColorPreset;
  opacity?: "10"|"20"|"30"|"40"|"50";
  flipX?: boolean;
  flipY?: boolean;
  blur?: DecorBlurPreset;
};

export type TwTokens = {
  layout?: {
    display?: DisplayPreset;
    position?: PositionPreset;
    zIndex?: "auto"|"0"|"10"|"20"|"30"|"40"|"50";

    // Shown when display === flex / inline-flex
    flex?: {
      dir?: FlexDirPreset;
      wrap?: FlexWrapPreset;
      justify?: JustifyPreset;
      items?: ItemsPreset;
    };

    // Shown when display === grid
    grid?: {
      cols?: GridColsPreset;
      rows?: GridRowsPreset;
      justifyItems?: JustifyItemsPreset;
      placeItems?: PlaceItemsPreset;
    };
  };
  style?: {
    bg?: BgPreset;
    bgColor?: string;
    radius?: RadiusPreset;
    shadow?: ShadowPreset;
  };
  state?: {
    hover?: HoverPreset;
  };
  motion?: {
    anim?: AnimPreset;
    delay?: DelayPreset;
    duration?: DurationPreset;
  };

  spacing?: {
    padding?: PaddingPreset;
    gap?: GapPreset;
  };
  typography?: {
    size?: TextSizePreset;
    align?: TextAlignPreset;
    weight?: FontWeightPreset;
    color?: TextColorPreset;
    colorCustom?: string;
  };
  size?: {
    maxW?: MaxWidthPreset;
  };
  decor?: {
    before?: DecorLayer;
    after?: DecorLayer;
  };

};
