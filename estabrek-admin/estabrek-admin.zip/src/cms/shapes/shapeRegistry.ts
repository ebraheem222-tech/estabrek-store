export type ShapeDef = {
  viewBox: string;
  d: string;
};

// Curated decorative SVG shapes (single-path). Use with preserveAspectRatio="none".
// Safe presets only (no user-provided SVG markup).
export const SHAPES: Record<string, ShapeDef> = {
  wave: {
    viewBox: "0 0 1440 160",
    d: "M0,64 C160,110 320,18 480,64 C640,110 800,18 960,64 C1120,110 1280,18 1440,64 L1440,160 L0,160 Z",
  },
  wave2: {
    viewBox: "0 0 1440 160",
    d: "M0,80 C120,20 240,20 360,80 C480,140 600,140 720,80 C840,20 960,20 1080,80 C1200,140 1320,140 1440,80 L1440,160 L0,160 Z",
  },
  diagonal: {
    viewBox: "0 0 1440 160",
    d: "M0,0 L1440,120 L1440,160 L0,160 Z",
  },
  curve: {
    viewBox: "0 0 1440 160",
    d: "M0,120 C240,40 480,40 720,120 C960,200 1200,200 1440,120 L1440,160 L0,160 Z",
  },
  zigzag: {
    viewBox: "0 0 1440 160",
    d: "M0,120 L120,80 L240,120 L360,80 L480,120 L600,80 L720,120 L840,80 L960,120 L1080,80 L1200,120 L1320,80 L1440,120 L1440,160 L0,160 Z",
  },
  blob: {
    viewBox: "0 0 1440 160",
    d: "M0,80 C120,10 260,10 360,70 C460,130 620,150 760,90 C900,30 1040,30 1160,80 C1280,130 1380,140 1440,120 L1440,160 L0,160 Z",
  },
  blob2: {
    viewBox: "0 0 1440 160",
    d: "M0,96 C180,20 360,20 540,96 C720,172 900,172 1080,96 C1260,20 1350,40 1440,72 L1440,160 L0,160 Z",
  },
};
