// src/features/inventory/InventoryAdjustmentsPage.tsx
import React, { useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

import { useAdjustments } from "../../hooks/useInventory";
import { Card } from "../../components/ui/Card";
import { PageHeader } from "../../components/ui/PageHeader";
import { Input } from "../../components/ui/Input";
import { Button } from "../../components/ui/Button";
import { Spinner } from "../../components/ui/Spinner";
import { Table, TBody, TD, TH, THead, TR } from "../../components/ui/Table";
import { Badge } from "../../components/ui/Badge";
import { Pagination } from "../../components/ui/Pagination";

function useQueryParam(name: string) {
  const loc = useLocation();
  return useMemo(() => {
    const sp = new URLSearchParams(loc.search);
    return sp.get(name);
  }, [loc.search, name]);
}

export default function InventoryAdjustmentsPage() {
  const nav = useNavigate();
  const variantIdFromUrl = useQueryParam("variantId") || "";

  const [variantId, setVariantId] = useState(variantIdFromUrl);
  const [page, setPage] = useState(1);
  const take = 30;
  const skip = (page - 1) * take;

  const q = useAdjustments({ variantId: variantId.trim() || undefined, take, skip });

  const total = q.data?.total ?? 0;
  const rows = q.data?.rows ?? [];
  const totalPages = Math.max(1, Math.ceil(total / take));

  return (
    <div dir="rtl" className="space-y-4">
      <PageHeader
        title="سجل تغييرات المخزون"
        subtitle={<span>إجمالي: <span className="font-semibold">{total}</span></span>}
        right={
          <div className="flex items-center gap-2">
            <Button variant="ghost" onClick={() => nav("/admin/inventory/low-stock")}>تنبيهات المخزون</Button>
            <Button variant="ghost" onClick={() => q.refetch()}>تحديث</Button>
          </div>
        }
      />

      <Card>
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-6">
            <div className="text-xs opacity-70 mb-1">Variant ID (اختياري)</div>
            <Input
              value={variantId}
              onChange={(e) => {
                setVariantId(e.target.value);
                setPage(1);
              }}
              placeholder="الصق variantId للتصفية"
            />
          </div>
          <div className="md:col-span-6 flex justify-end">
            <Button variant="secondary" onClick={() => { setVariantId(""); setPage(1); }}>
              مسح الفلتر
            </Button>
          </div>
        </div>
      </Card>

      <Card padding="none">
        {q.isLoading ? (
          <div className="p-6"><Spinner /></div>
        ) : (
          <>
            <Table>
              <THead>
                <TR>
                  <TH>الوقت</TH>
                  <TH>المنتج</TH>
                  <TH>SKU / مقاس</TH>
                  <TH>التغيير</TH>
                  <TH>قبل → بعد</TH>
                  <TH>السبب</TH>
                  <TH>المدير</TH>
                </TR>
              </THead>
              <TBody>
                {rows.length ? (
                  rows.map((r) => (
                    <TR key={r.id}>
                      <TD className="text-xs opacity-70">{new Date(r.createdAt).toLocaleString()}</TD>
                      <TD>
                        <div className="font-medium">{r.productTitle ?? "—"}</div>
                        <div className="text-xs opacity-60 font-mono">{r.variantId}</div>
                      </TD>
                      <TD>
                        <div className="font-mono text-xs">{r.sku ?? "—"}</div>
                        <div className="text-xs opacity-60">{r.size ?? "—"}</div>
                      </TD>
                      <TD>
                        {r.delta >= 0 ? (
                          <Badge variant="success">+{r.delta}</Badge>
                        ) : (
                          <Badge variant="danger">{r.delta}</Badge>
                        )}
                      </TD>
                      <TD className="font-semibold">{r.beforeStock} → {r.afterStock}</TD>
                      <TD className="text-sm">{r.reason ?? "—"}</TD>
                      <TD>
                        <div className="text-sm">{r.adminUser?.name ?? r.adminUser?.email ?? "—"}</div>
                        {r.adminUser?.email ? <div className="text-xs opacity-60">{r.adminUser.email}</div> : null}
                      </TD>
                    </TR>
                  ))
                ) : (
                  <TR>
                    <TD colSpan={7} className="p-6 text-center text-white/60">لا يوجد سجلات</TD>
                  </TR>
                )}
              </TBody>
            </Table>
            <Pagination page={page} totalPages={totalPages} onChange={setPage} className="p-4" />
          </>
        )}
      </Card>
    </div>
  );
}
