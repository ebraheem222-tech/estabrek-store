"use client";
import { useLanguage } from "./cinematic/Language";

import React, { useEffect, useMemo, useRef, useState, useTransition } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { buildCanonicalQuery, type CatalogFilters, normalizeFiltersFromSearchParams } from "@/lib/filtersUrl";
import { CategorySidebar } from "@/components/CategorySidebar";
import { gsap } from "gsap";
import { useStorefrontSettings } from "@/components/StorefrontFeaturesProvider";

type FacetColor = { name: string; hex?: string | null; count: number };
type FacetSize = { id: string; name: string; count: number };

// Icons
const SearchIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
  </svg>
);

const CategoryIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
  </svg>
);

const SortIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
  </svg>
);

const PriceIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const ColorIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
  </svg>
);

const SizeIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" />
  </svg>
);

const FilterIcon = () => (
  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
  </svg>
);

const CloseIcon = () => (
  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const TrashIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
  </svg>
);

const ChevronDownIcon = () => (
  <svg className="w-4 h-4 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
  </svg>
);

const XIcon = () => (
  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const CheckIcon = () => (
  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
  </svg>
);

function uniqCaseInsensitive(arr: string[]): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const a of arr) {
    const k = a.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(a);
  }
  return out;
}

export function ProductFiltersBar({
  colors,
  sizes,
  categories,
  className,
  filters,
  onFiltersChange,
  syncUrl = true,
  hideCategory = false,
  mobileCategoryTree = false,
  categoryTree = false,
  mobileAutoApply = false,
  appearance = "default",
}: {
  colors: FacetColor[];
  sizes: FacetSize[];
  categories: { id: string; name: string; parentId?: string | null }[];
  className?: string;
  filters?: CatalogFilters;
  onFiltersChange?: (next: CatalogFilters) => void;
  syncUrl?: boolean;
  hideCategory?: boolean;
  mobileCategoryTree?: boolean;
  categoryTree?: boolean;
  mobileAutoApply?: boolean;
  appearance?: "rose" | "default";
}) {
  const ar = useLanguage().language === "ar";
  const settings = useStorefrontSettings();
  const router = useRouter();
  const pathname = usePathname() ?? "";
  const sp = useSearchParams();
  const [, startTransition] = useTransition();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  const [draftFilters, setDraftFilters] = useState<CatalogFilters | null>(null);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    colors: true,
    sizes: true,
  });

  const urlFilters = useMemo(() => {
    const obj: Record<string, string> = {};
    sp?.forEach((v, k) => {
      obj[k] = v;
    });
    return normalizeFiltersFromSearchParams(obj);
  }, [sp]);

  const currentFilters = useMemo(() => {
    const src = filters ?? urlFilters;
    return {
      ...src,
      colors: src.colors ?? [],
      sizeIds: src.sizeIds ?? [],
    } as CatalogFilters;
  }, [filters, urlFilters]);

  useEffect(() => {
    if (!mobileOpen || mobileAutoApply) {
      setDraftFilters(null);
      return;
    }
    setDraftFilters({
      ...currentFilters,
      colors: currentFilters.colors ?? [],
      sizeIds: currentFilters.sizeIds ?? [],
    });
  }, [mobileOpen, currentFilters, mobileAutoApply]);

  const workingFilters = mobileOpen && draftFilters && !mobileAutoApply ? draftFilters : currentFilters;

  const sortParam = workingFilters.sort ?? "latest";
  const minPriceParam = workingFilters.minPrice != null ? String(workingFilters.minPrice) : "";
  const maxPriceParam = workingFilters.maxPrice != null ? String(workingFilters.maxPrice) : "";
  const qParam = workingFilters.q ?? "";
  const inStockParam = !!workingFilters.inStock;
  const categoryIdParam = workingFilters.categoryId ?? "";

  const selectedColors = workingFilters.colors ?? [];
  const selectedSizes = workingFilters.sizeIds ?? [];

  const selectedCategory = useMemo(() => {
    return categories.find(c => c.id === categoryIdParam);
  }, [categories, categoryIdParam]);

  const categoryOptions = useMemo(() => {
    const byParent = new Map<string | null, { id: string; name: string; parentId?: string | null }[]>();
    const byId = new Map<string, { id: string; name: string; parentId?: string | null }>();
    for (const c of categories) {
      byId.set(c.id, c);
      const pid = c.parentId ?? null;
      const list = byParent.get(pid) ?? [];
      list.push(c);
      byParent.set(pid, list);
    }

    const out: Array<{ id: string; name: string; depth: number }> = [];
    const seen = new Set<string>();
    const walk = (pid: string | null, depth: number) => {
      const list = byParent.get(pid) ?? [];
      for (const c of list) {
        if (seen.has(c.id)) continue;
        seen.add(c.id);
        out.push({ id: c.id, name: c.name, depth });
        walk(c.id, depth + 1);
      }
    };

    // Start with root categories (parentId is null)
    walk(null, 0);

    // Add any orphans (parentId exists but missing in list)
    for (const c of categories) {
      if (!c.parentId || byId.has(c.parentId)) continue;
      if (seen.has(c.id)) continue;
      out.push({ id: c.id, name: c.name, depth: 0 });
      walk(c.id, 1);
    }

    // Add any remaining items
    for (const c of categories) {
      if (seen.has(c.id)) continue;
      out.push({ id: c.id, name: c.name, depth: 0 });
    }

    return out;
  }, [categories]);

  const [qInput, setQInput] = useState(qParam);
  const mobileDialog = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!mobileOpen || appearance !== "rose" || !settings.scrollAnimationsEnabled || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const context = gsap.context(() => {
      if (isClosing) {
        gsap.to(".filter-mobile-drawer-candy", { xPercent: 100, duration: .24, ease: "power2.in" });
        gsap.to(".filter-backdrop", { opacity: 0, duration: .24 });
      } else {
        gsap.fromTo(".filter-mobile-drawer-candy", { xPercent: 100 }, { xPercent: 0, duration: .4, ease: "power3.out" });
        gsap.fromTo(".filter-backdrop", { opacity: 0 }, { opacity: 1, duration: .3 });
      }
    }, mobileDialog);
    return () => context.revert();
  }, [mobileOpen, isClosing, appearance, settings.scrollAnimationsEnabled]);
  const [minInput, setMinInput] = useState(minPriceParam);
  const [maxInput, setMaxInput] = useState(maxPriceParam);

  useEffect(() => {
    setQInput(qParam);
  }, [qParam]);

  useEffect(() => {
    setMinInput(minPriceParam);
  }, [minPriceParam]);

  useEffect(() => {
    setMaxInput(maxPriceParam);
  }, [maxPriceParam]);

  useEffect(() => {
    if (!mobileOpen || typeof window === "undefined") return;
    const previousFocus = document.activeElement as HTMLElement | null;
    const dialog = mobileDialog.current;
    dialog?.querySelector<HTMLElement>('button[aria-label="Close filters"]')?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeMobile();
      if (e.key === "Tab" && dialog) {
        const controls = Array.from(dialog.querySelectorAll<HTMLElement>('button:not([disabled]),input:not([disabled]),select:not([disabled]),a[href]')).filter(el => el.getClientRects().length && getComputedStyle(el).visibility !== "hidden");
        const first = controls[0], last = controls[controls.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last?.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first?.focus(); }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => { window.removeEventListener("keydown", onKey); previousFocus?.focus(); };
  }, [mobileOpen]);

  // Build active filters array for tags display
  const activeFilters = useMemo(() => {
    const filters: Array<{ type: string; label: string; value: string }> = [];
    if (qParam) filters.push({ type: "q", label: `${ar ? "بحث" : "Search"}: ${qParam}`, value: qParam });
    if (selectedCategory) filters.push({ type: "categoryId", label: selectedCategory.name, value: categoryIdParam });
    if (inStockParam) filters.push({ type: "inStock", label: ar ? "متوفر فقط" : "In stock", value: "1" });
    if (minPriceParam) filters.push({ type: "minPrice", label: `${ar ? "من" : "From"}: ₪${minPriceParam}`, value: minPriceParam });
    if (maxPriceParam) filters.push({ type: "maxPrice", label: `${ar ? "إلى" : "To"}: ₪${maxPriceParam}`, value: maxPriceParam });
    selectedColors.forEach(c => filters.push({ type: "color", label: c, value: c }));
    selectedSizes.forEach(s => {
      const size = sizes.find(sz => sz.id === s);
      filters.push({ type: "size", label: size?.name || s, value: s });
    });
    return filters;
  }, [qParam, selectedCategory, categoryIdParam, inStockParam, minPriceParam, maxPriceParam, selectedColors, selectedSizes, sizes, ar]);

  const activeFiltersCount = activeFilters.length;
  const hasAny = activeFiltersCount > 0;

  useEffect(() => {
    const t = setTimeout(() => {
      if (qInput !== qParam) setSimple("q", qInput.trim() || undefined, { replace: true });
    }, 350);
    return () => clearTimeout(t);
  }, [qInput, qParam]);

  useEffect(() => {
    const t = setTimeout(() => {
      if (minInput !== minPriceParam) setSimple("minPrice", minInput.trim() || undefined, { replace: true });
    }, 400);
    return () => clearTimeout(t);
  }, [minInput, minPriceParam]);

  useEffect(() => {
    const t = setTimeout(() => {
      if (maxInput !== maxPriceParam) setSimple("maxPrice", maxInput.trim() || undefined, { replace: true });
    }, 400);
    return () => clearTimeout(t);
  }, [maxInput, maxPriceParam]);

  function normalizeFilters(next: CatalogFilters): CatalogFilters {
    const colorsNorm = uniqCaseInsensitive(next.colors ?? []).sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: "base" })
    );
    const sizesNorm = uniqCaseInsensitive(next.sizeIds ?? []).sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: "base" })
    );
    const out: CatalogFilters = { colors: colorsNorm, sizeIds: sizesNorm };
    if (next.minPrice != null && Number.isFinite(next.minPrice as any)) out.minPrice = next.minPrice;
    if (next.maxPrice != null && Number.isFinite(next.maxPrice as any)) out.maxPrice = next.maxPrice;
    if (out.minPrice != null && out.maxPrice != null && out.minPrice > out.maxPrice) {
      const t = out.minPrice;
      out.minPrice = out.maxPrice;
      out.maxPrice = t;
    }
    if (next.sort) out.sort = next.sort;
    if (next.q) out.q = next.q;
    if (next.inStock) out.inStock = true;
    if (next.categoryId) out.categoryId = next.categoryId;
    if (next.page && next.page > 1) out.page = next.page;
    if (next.lm) out.lm = next.lm;
    return out;
  }

  function push(next: CatalogFilters, opts?: { replace?: boolean }) {
    if (!pathname) return;
    const qs = buildCanonicalQuery(next);
    const url = qs ? `${pathname}?${qs}` : pathname;
    if (onFiltersChange) {
      if (syncUrl && typeof window !== "undefined") {
        const method = opts?.replace ? "replaceState" : "pushState";
        window.history[method]({}, "", url);
      }
      return;
    }
    startTransition(() => {
      if (opts?.replace) router.replace(url);
      else router.push(url);
    });
  }

  function removeFilter(type: string, value: string) {
    const next: CatalogFilters = {
      ...workingFilters,
      colors: [...(workingFilters.colors ?? [])],
      sizeIds: [...(workingFilters.sizeIds ?? [])],
    };
    if (type === "color") {
      next.colors = next.colors.filter((c) => c.toLowerCase() !== value.toLowerCase());
    } else if (type === "size") {
      next.sizeIds = next.sizeIds.filter((s) => s !== value);
    } else {
      (next as any)[type] = undefined;
    }
    next.page = undefined;
    const normalized = normalizeFilters(next);
    if (mobileOpen && !mobileAutoApply) {
      setDraftFilters(normalized);
    } else {
      onFiltersChange?.(normalized);
      push(normalized);
    }
  }

  function toggleColor(name: string) {
    const next: CatalogFilters = {
      ...workingFilters,
      colors: [...(workingFilters.colors ?? [])],
      sizeIds: [...(workingFilters.sizeIds ?? [])],
    };
    const exists = next.colors.some((c) => c.toLowerCase() === name.toLowerCase());
    next.colors = exists ? next.colors.filter((c) => c.toLowerCase() !== name.toLowerCase()) : [...next.colors, name];
    next.page = undefined;
    const normalized = normalizeFilters(next);
    if (mobileOpen && !mobileAutoApply) {
      setDraftFilters(normalized);
    } else {
      onFiltersChange?.(normalized);
      push(normalized);
    }
  }

  function toggleSize(id: string) {
    const next: CatalogFilters = {
      ...workingFilters,
      colors: [...(workingFilters.colors ?? [])],
      sizeIds: [...(workingFilters.sizeIds ?? [])],
    };
    const exists = next.sizeIds.includes(id);
    next.sizeIds = exists ? next.sizeIds.filter((s) => s !== id) : [...next.sizeIds, id];
    next.page = undefined;
    const normalized = normalizeFilters(next);
    if (mobileOpen && !mobileAutoApply) {
      setDraftFilters(normalized);
    } else {
      onFiltersChange?.(normalized);
      push(normalized);
    }
  }

  function setSimple(key: string, value?: string, opts?: { replace?: boolean }) {
    const next: CatalogFilters = {
      ...workingFilters,
      colors: [...(workingFilters.colors ?? [])],
      sizeIds: [...(workingFilters.sizeIds ?? [])],
    };
    if (!value) {
      (next as any)[key] = undefined;
    } else if (key === "minPrice" || key === "maxPrice") {
      const num = Number(value);
      (next as any)[key] = Number.isFinite(num) ? num : undefined;
    } else if (key === "inStock") {
      (next as any)[key] = value ? true : undefined;
    } else {
      (next as any)[key] = value;
    }
    next.page = undefined;
    const normalized = normalizeFilters(next);
    if (mobileOpen && !mobileAutoApply) {
      setDraftFilters(normalized);
    } else {
      onFiltersChange?.(normalized);
      push(normalized, opts);
    }
  }

  function clearAll() {
    const normalized = normalizeFilters({ colors: [], sizeIds: [] });
    if (mobileOpen && !mobileAutoApply) {
      setDraftFilters(normalized);
    } else {
      onFiltersChange?.(normalized);
      push(normalized);
    }
  }

  function closeMobile() {
    if (!mobileOpen || isClosing) return;
    setIsClosing(true);
    window.setTimeout(() => {
      setMobileOpen(false);
      setDraftFilters(null);
      setIsClosing(false);
    }, 280);
  }

  function applyMobile() {
    if (mobileAutoApply) {
      closeMobile();
      return;
    }
    const normalized = normalizeFilters(draftFilters ?? workingFilters);
    onFiltersChange?.(normalized);
    push(normalized);
    setMobileOpen(false);
    setDraftFilters(null);
  }

  function toggleSection(section: string) {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  }

  const filtersContent = (
    <div className="space-y-5">
      {/* Active Filter Tags */}
      {hasAny && (
        <div className="filter-tags">
          {activeFilters.map((filter, idx) => (
            <span key={`${filter.type}-${filter.value}-${idx}`} className="filter-tag">
              {filter.label}
              <button
                type="button"
                onClick={() => removeFilter(filter.type, filter.value)}
                className="filter-tag-remove"
              >
                <XIcon />
              </button>
            </span>
          ))}
        </div>
      )}

      {/* Search Input */}
      <div className="filter-section">
        <label className="filter-label">
          <SearchIcon />
          {ar ? "بحث" : "Search"}
        </label>
        <div className="relative">
          <input
            className="filter-input pr-10"
            value={qInput}
            onChange={(e) => setQInput(e.target.value)}
            placeholder={ar ? "ابحث عن منتج..." : "Search products…"}
          />
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--muted)]">
            <SearchIcon />
          </div>
        </div>
      </div>

      {/* Category Tree */}
      {categoryTree ? (
        <div className="filter-section">
          <label className="filter-label">
            <CategoryIcon />
            {ar ? "التصنيف" : "Category"}
          </label>
          <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
            <CategorySidebar
              categories={categories}
              selectedId={categoryIdParam || undefined}
              onSelect={(id) => setSimple("categoryId", id || undefined)}
            />
          </div>
        </div>
      ) : null}

      {/* Category & Sort Row */}
      <div className="grid gap-4 sm:grid-cols-2">
        {!hideCategory && !categoryTree ? (
          <div className="filter-section">
            <label className="filter-label">
              <CategoryIcon />
              {ar ? "التصنيف" : "Category"}
            </label>
            <select
              className="filter-select"
              value={categoryIdParam}
              onChange={(e) => setSimple("categoryId", e.target.value || undefined)}
            >
              <option value="">{ar ? "جميع التصنيفات" : "All categories"}</option>
              {categoryOptions.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.depth > 0 ? `${"— ".repeat(c.depth)}${c.name}` : c.name}
                </option>
              ))}
            </select>
          </div>
        ) : null}

        <div className="filter-section">
          <label className="filter-label">
            <SortIcon />
            {ar ? "الترتيب" : "Sort by"}
          </label>
          <select
            className="filter-select"
            value={sortParam}
            onChange={(e) => setSimple("sort", e.target.value)}
          >
            <option value="latest">{ar ? "الأحدث" : "Latest"}</option>
            <option value="title_asc">{ar ? "العنوان أ→ي" : "Name: A–Z"}</option>
            <option value="title_desc">{ar ? "العنوان ي→أ" : "Name: Z–A"}</option>
            <option value="price_asc">{ar ? "السعر: الأقل أولاً" : "Price: low to high"}</option>
            <option value="price_desc">{ar ? "السعر: الأعلى أولاً" : "Price: high to low"}</option>
          </select>
        </div>
      </div>

      {/* Price Range */}
      <div className="filter-section">
        <label className="filter-label">
          <PriceIcon />
          {ar ? "نطاق السعر" : "Price range"}
        </label>
        <div className="price-range-container">
          <div className="relative flex-1">
            <input
              className="price-range-input"
              value={minInput}
              onChange={(e) => setMinInput(e.target.value)}
              placeholder={ar ? "الحد الأدنى" : "Min price"}
              inputMode="numeric"
              dir="ltr"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[var(--muted)]">₪</span>
          </div>
          <div className="flex items-center justify-center w-8">
            <span className="price-range-separator">—</span>
          </div>
          <div className="relative flex-1">
            <input
              className="price-range-input"
              value={maxInput}
              onChange={(e) => setMaxInput(e.target.value)}
              placeholder={ar ? "الحد الأقصى" : "Max price"}
              inputMode="numeric"
              dir="ltr"
            />
            <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[var(--muted)]">₪</span>
          </div>
        </div>
      </div>

      {/* In Stock Toggle */}
      <div className="filter-section">
        <button
          type="button"
          onClick={() => setSimple("inStock", inStockParam ? undefined : "1")}
          className={`filter-toggle ${inStockParam ? "active" : ""}`}
        >
          <div className="flex items-center gap-3">
            <div className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-all ${
              inStockParam 
                ? "bg-[var(--accent)] border-[var(--accent)]" 
                : "border-white/20 bg-transparent"
            }`}>
              {inStockParam && <CheckIcon />}
            </div>
            <span className="font-medium">{ar ? "المتوفر فقط" : "In stock only"}</span>
          </div>
          <span className="filter-toggle-indicator" />
        </button>
      </div>

      {/* Colors Accordion */}
      {colors.length > 0 && (
        <div className={`filter-accordion ${expandedSections.colors ? "open" : ""}`}>
          <button
            type="button"
            className="filter-accordion-header"
            onClick={() => toggleSection("colors")}
          >
            <div className="flex items-center gap-2">
              <ColorIcon />
              <span className="font-medium">{ar ? "الألوان" : "Colours"}</span>
              {selectedColors.length > 0 && (
                <span className="active-filters-count">{selectedColors.length}</span>
              )}
            </div>
            <div className={`transition-transform duration-300 ${expandedSections.colors ? "rotate-180" : ""}`}>
              <ChevronDownIcon />
            </div>
          </button>
          <div className={`filter-accordion-content ${expandedSections.colors ? "expanded" : ""}`}>
            <div className="filter-accordion-body">
              <div className="color-chips-container">
                {colors.map((c, i) => {
                  const active = selectedColors.some((x) => x.toLowerCase() === c.name.toLowerCase());
                  // The API sends colorHex (older code read hex).
                  const raw = c.hex ?? (c as { colorHex?: string | null }).colorHex ?? null;
                  const hex = raw?.startsWith("#") ? raw : raw ? `#${raw}` : null;
                  return (
                    <button
                      // The catalog can list one colour name with two shades (e.g. two "ليلكي"): keep keys unique.
                      key={`${c.name}-${c.hex ?? ""}-${i}`}
                      type="button"
                      onClick={() => toggleColor(c.name)}
                      className={`color-chip ${active ? "active" : ""}`}
                    >
                      <span 
                        className="color-chip-swatch" 
                        style={{ background: hex ?? "linear-gradient(135deg, #ddd, #888)" }} 
                      />
                      <span>{c.name}</span>
                      <span className="color-chip-count">({c.count})</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Sizes Accordion */}
      {sizes.length > 0 && (
        <div className={`filter-accordion ${expandedSections.sizes ? "open" : ""}`}>
          <button
            type="button"
            className="filter-accordion-header"
            onClick={() => toggleSection("sizes")}
          >
            <div className="flex items-center gap-2">
              <SizeIcon />
              <span className="font-medium">{ar ? "المقاسات" : "Sizes"}</span>
              {selectedSizes.length > 0 && (
                <span className="active-filters-count">{selectedSizes.length}</span>
              )}
            </div>
            <div className={`transition-transform duration-300 ${expandedSections.sizes ? "rotate-180" : ""}`}>
              <ChevronDownIcon />
            </div>
          </button>
          <div className={`filter-accordion-content ${expandedSections.sizes ? "expanded" : ""}`}>
            <div className="filter-accordion-body">
              <div className="size-chips-grid">
                {sizes.map((s) => {
                  const active = selectedSizes.includes(s.id);
                  return (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => toggleSize(s.id)}
                      className={`size-chip ${active ? "active" : ""}`}
                    >
                      {s.name}
                      <span className="text-xs opacity-60 mr-1">({s.count})</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className={`filter-candy-shell ${className ?? ""}`.trim()} dir={ar ? "rtl" : "ltr"}>
      {/* Mobile Filter Toggle */}
      <button 
        type="button" 
        onClick={() => {
          setIsClosing(false);
          setMobileOpen(true);
        }} 
        aria-expanded={mobileOpen}
        className={`mobile-filter-toggle filter-mobile-toggle-candy ${appearance === "rose" ? "lg:hidden" : "md:hidden"} ${mobileOpen ? "opacity-0 pointer-events-none" : ""}`}
      >
        <FilterIcon />
        <span>{ar ? "الفلاتر" : "Filters"}</span>
        {activeFiltersCount > 0 && (
          <span className="active-filters-count">{activeFiltersCount}</span>
        )}
      </button>

      {/* Desktop Filters */}
      <div className={`filters-container filters-candy-surface hidden ${appearance === "rose" ? "lg:block" : "md:block"}`}>
        <div className="filters-header">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--accent)] to-[var(--accent-2)] flex items-center justify-center text-white">
              <FilterIcon />
            </div>
            <div>
              <h3 className="font-bold text-[var(--text)]">{ar ? "الفلاتر" : "Filters"}</h3>
              {activeFiltersCount > 0 && (
                <p className="text-xs text-[var(--muted)]">{activeFiltersCount} {ar ? "فلتر نشط" : "active filters"}</p>
              )}
            </div>
          </div>
          {hasAny && (
            <button type="button" onClick={clearAll} className="clear-filters-btn">
              <TrashIcon />
              {ar ? "مسح الكل" : "Clear all"}
            </button>
          )}
        </div>
        {filtersContent}
      </div>

      {/* Mobile Filters Modal */}
      {mobileOpen && (
        <div ref={mobileDialog} className={`fixed inset-0 z-[1300] ${appearance === "rose" ? "lg:hidden" : "md:hidden"}`} role="dialog" aria-modal="true" aria-label={ar ? "الفلاتر" : "Filters"}>
          <div 
            className={`absolute inset-0 filter-backdrop filter-backdrop-candy ${isClosing ? "closing" : "opening"}`} 
            onClick={closeMobile} 
          />
          <div 
            className={`absolute inset-y-0 right-0 w-[82vw] max-w-[540px] overflow-y-auto filter-mobile-drawer-candy ${isClosing ? "filter-drawer-closing" : "filter-drawer-opening"}`}
          >
            {/* Mobile Header */}
            <div className="sticky top-0 z-20 flex items-center justify-between p-4 border-b border-white/40 filter-mobile-header-candy">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--accent)] to-[var(--accent-2)] flex items-center justify-center text-white">
                  <FilterIcon />
                </div>
                <div>
                  <h3 className="font-bold text-[var(--text)]">{ar ? "الفلاتر" : "Filters"}</h3>
                  {activeFiltersCount > 0 && (
                    <p className="text-xs text-[var(--muted)]">{activeFiltersCount} {ar ? "فلتر نشط" : "active filters"}</p>
                  )}
                </div>
              </div>
              <button 
                type="button" 
                onClick={closeMobile} 
                className="inline-flex items-center gap-2 rounded-xl px-3 py-2 text-[var(--text)] transition-all duration-300 filter-mobile-close-btn"
                aria-label="Close filters"
              >
                <CloseIcon />
                <span className="text-sm font-medium">{ar ? "إغلاق" : "Close"}</span>
              </button>
            </div>

            {/* Mobile Content */}
            <div className="p-4 pb-28">
              {mobileCategoryTree && !categoryTree && categories?.length ? (
                <div className="mb-5 rounded-2xl border border-white/40 p-3 filter-tree-candy">
                  <CategorySidebar
                    categories={categories}
                    selectedId={categoryIdParam || undefined}
                    onSelect={(id) => setSimple("categoryId", id || undefined)}
                  />
                </div>
              ) : null}
              {filtersContent}
            </div>

            {/* Mobile Footer */}
            <div className="sticky bottom-0 z-20 p-4 border-t border-white/40 flex gap-3 filter-mobile-footer-candy">
              {hasAny && (
                <button 
                  type="button" 
                  onClick={clearAll} 
                  className="flex-1 py-3 rounded-xl border border-white/45 text-[var(--text)] font-medium transition-all duration-300 filter-mobile-clear-btn"
                >
                  {ar ? "مسح الكل" : "Clear all"}
                </button>
              )}
              {!mobileAutoApply && (
                <button 
                  type="button" 
                  onClick={applyMobile} 
                  className="flex-1 py-3 rounded-xl text-white font-semibold transition-all duration-300 filter-mobile-apply-btn"
                >
                  {ar ? "تطبيق الفلاتر" : "Apply filters"}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        @keyframes slideInRight {
          from {
            transform: translateX(100%) scale(0.97);
            opacity: 0;
            filter: blur(8px);
          }
          64% {
            transform: translateX(-1.4%) scale(1.005);
          }
          to {
            transform: translateX(0) scale(1);
            opacity: 1;
            filter: blur(0);
          }
        }

        @keyframes slideOutRight {
          from {
            transform: translateX(0) scale(1);
            opacity: 1;
            filter: blur(0);
          }
          to {
            transform: translateX(100%) scale(0.98);
            opacity: 0;
            filter: blur(8px);
          }
        }

        @keyframes candyBackdropIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }

        @keyframes candyBackdropOut {
          from {
            opacity: 1;
          }
          to {
            opacity: 0;
          }
        }

        @keyframes candyPopUp {
          from {
            opacity: 0;
            transform: translateY(12px) scale(0.98);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        .filter-drawer-opening {
          animation: slideInRight 0.36s cubic-bezier(0.22, 1, 0.36, 1);
        }

        .filter-drawer-closing {
          animation: slideOutRight 0.28s cubic-bezier(0.4, 0, 1, 1) forwards;
        }

        .filter-backdrop-candy.opening {
          animation: candyBackdropIn 0.32s ease forwards;
        }

        .filter-backdrop-candy.closing {
          animation: candyBackdropOut 0.22s ease forwards;
        }

        .filter-candy-shell .filter-section,
        .filter-candy-shell .filter-accordion,
        .filter-candy-shell .filter-tags {
          animation: candyPopUp 0.38s cubic-bezier(0.22, 1, 0.36, 1) both;
        }

        .filter-candy-shell .filter-section:nth-of-type(1) { animation-delay: 0ms; }
        .filter-candy-shell .filter-section:nth-of-type(2) { animation-delay: 40ms; }
        .filter-candy-shell .filter-section:nth-of-type(3) { animation-delay: 80ms; }
        .filter-candy-shell .filter-section:nth-of-type(4) { animation-delay: 120ms; }

        .filter-accordion-content {
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.36s ease;
        }
        
        .filter-accordion-content.expanded {
          max-height: 560px;
        }

        .filter-mobile-toggle-candy {
          background: linear-gradient(
              160deg,
              color-mix(in srgb, var(--accent, #f472b6) 72%, white 28%),
              color-mix(in srgb, var(--accent-2, #f59e0b) 66%, white 34%)
            ),
            rgba(255, 255, 255, 0.68);
          border: 1px solid rgba(255, 255, 255, 0.88);
          box-shadow:
            0 16px 34px rgba(244, 114, 182, 0.24),
            0 10px 24px rgba(56, 189, 248, 0.18);
          backdrop-filter: blur(20px) saturate(150%);
          -webkit-backdrop-filter: blur(20px) saturate(150%);
        }

        .filters-candy-surface {
          position: relative;
          overflow: hidden;
          background:
            radial-gradient(130% 100% at 100% 0%, rgba(250, 204, 21, 0.12), transparent 60%),
            radial-gradient(120% 100% at 0% 0%, rgba(244, 114, 182, 0.2), transparent 58%),
            radial-gradient(140% 120% at 30% 100%, rgba(236, 72, 153, 0.14), transparent 64%),
            linear-gradient(150deg, rgba(255, 238, 247, 0.88), rgba(255, 231, 247, 0.74));
          border: 1px solid rgba(244, 171, 214, 0.58);
          box-shadow:
            0 16px 34px rgba(236, 72, 153, 0.16),
            0 14px 34px rgba(99, 102, 241, 0.1);
          backdrop-filter: blur(24px) saturate(150%);
          -webkit-backdrop-filter: blur(24px) saturate(150%);
        }

        .filters-candy-surface::after {
          content: "";
          position: absolute;
          inset: 0;
          pointer-events: none;
          background: linear-gradient(120deg, rgba(255, 255, 255, 0.38), rgba(255, 255, 255, 0.02) 52%);
        }

        .filter-mobile-drawer-candy {
          background:
            radial-gradient(130% 100% at 100% 0%, rgba(251, 191, 36, 0.14), transparent 58%),
            radial-gradient(130% 110% at 0% 0%, rgba(244, 114, 182, 0.24), transparent 58%),
            linear-gradient(165deg, rgba(255, 240, 249, 0.92), rgba(255, 233, 249, 0.78));
          border-left: 1px solid rgba(243, 169, 212, 0.58);
          box-shadow:
            -16px 0 34px rgba(67, 56, 202, 0.16),
            -10px 0 26px rgba(236, 72, 153, 0.14);
          backdrop-filter: blur(28px) saturate(158%);
          -webkit-backdrop-filter: blur(28px) saturate(158%);
        }

        .filter-mobile-header-candy,
        .filter-mobile-footer-candy {
          background: linear-gradient(160deg, rgba(255, 242, 249, 0.88), rgba(255, 232, 248, 0.72));
          backdrop-filter: blur(18px) saturate(140%);
          -webkit-backdrop-filter: blur(18px) saturate(140%);
        }

        .filter-mobile-close-btn,
        .filter-mobile-clear-btn {
          background: linear-gradient(135deg, rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.68));
          box-shadow: 0 8px 18px rgba(99, 102, 241, 0.1);
        }

        .filter-mobile-close-btn:hover,
        .filter-mobile-clear-btn:hover {
          transform: translateY(-1px);
          box-shadow: 0 10px 22px rgba(236, 72, 153, 0.16);
        }

        .filter-mobile-apply-btn {
          background: linear-gradient(
            145deg,
            color-mix(in srgb, var(--accent, #f472b6) 72%, white 28%),
            color-mix(in srgb, var(--accent-2, #f59e0b) 70%, white 30%)
          );
          box-shadow:
            0 12px 24px rgba(244, 114, 182, 0.24),
            0 8px 18px rgba(14, 165, 233, 0.18);
        }

        .filter-mobile-apply-btn:hover {
          transform: translateY(-1px);
          box-shadow:
            0 14px 28px rgba(244, 114, 182, 0.3),
            0 10px 22px rgba(14, 165, 233, 0.22);
        }

        .filter-tree-candy {
          background: linear-gradient(145deg, rgba(255, 255, 255, 0.72), rgba(255, 255, 255, 0.5));
          box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.5);
        }

        .filter-candy-shell .filters-header {
          border-bottom-color: rgba(255, 255, 255, 0.62);
        }

        .filter-candy-shell .filter-label {
          color: color-mix(in srgb, var(--text) 62%, white 38%);
        }

        .filter-candy-shell .filter-input,
        .filter-candy-shell .filter-select,
        .filter-candy-shell .price-range-input,
        .filter-candy-shell .filter-toggle,
        .filter-candy-shell .filter-accordion,
        .filter-candy-shell .color-chip,
        .filter-candy-shell .size-chip {
          background: linear-gradient(150deg, rgba(255, 241, 248, 0.86), rgba(255, 233, 248, 0.72));
          border-color: rgba(243, 169, 212, 0.54);
          color: var(--text);
          box-shadow: 0 8px 18px rgba(99, 102, 241, 0.08);
        }

        .filter-candy-shell .filter-accordion {
          border-radius: 1.55rem;
          border-color: rgba(243, 169, 212, 0.58);
          background:
            radial-gradient(120% 100% at 100% 0%, rgba(250, 204, 21, 0.08), transparent 64%),
            radial-gradient(120% 100% at 0% 0%, rgba(244, 114, 182, 0.2), transparent 68%),
            linear-gradient(150deg, rgba(255, 241, 248, 0.88), rgba(255, 232, 248, 0.74));
          box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.82),
            0 12px 26px rgba(15, 23, 42, 0.1);
        }

        .filter-candy-shell .filter-accordion-header {
          border-bottom: 1px solid rgba(243, 169, 212, 0.52);
          border-top-left-radius: 1.5rem;
          border-top-right-radius: 1.5rem;
          background: linear-gradient(140deg, rgba(255, 243, 250, 0.84), rgba(255, 234, 248, 0.72));
        }

        .filter-candy-shell .filter-accordion-body {
          padding: 0.9rem 0.95rem 1rem;
          background: linear-gradient(150deg, rgba(255, 240, 248, 0.78), rgba(255, 231, 248, 0.66));
          border-bottom-left-radius: 1.5rem;
          border-bottom-right-radius: 1.5rem;
        }

        .filter-candy-shell .size-chips-grid {
          display: flex;
          flex-wrap: wrap;
          gap: 0.58rem;
        }

        .filter-candy-shell .filter-input::placeholder,
        .filter-candy-shell .price-range-input::placeholder,
        .filter-candy-shell .color-chip-count {
          color: color-mix(in srgb, var(--text) 44%, white 56%);
        }

        .filter-candy-shell .filter-select {
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='%2364748b' stroke-width='2'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E");
        }

        .filter-candy-shell .filter-select option {
          background: #f8f9ff;
          color: #1f2937;
        }

        .filter-candy-shell .filter-input:focus,
        .filter-candy-shell .filter-select:focus,
        .filter-candy-shell .price-range-input:focus {
          border-color: color-mix(in srgb, var(--accent) 65%, white 35%);
          box-shadow:
            0 0 0 3px color-mix(in srgb, var(--accent) 18%, white 82%),
            0 12px 24px rgba(244, 114, 182, 0.18);
        }

        .filter-candy-shell .filter-toggle:hover,
        .filter-candy-shell .filter-accordion-header:hover,
        .filter-candy-shell .color-chip:hover,
        .filter-candy-shell .size-chip:hover {
          background: linear-gradient(145deg, rgba(255, 255, 255, 0.94), rgba(255, 255, 255, 0.72));
          border-color: rgba(255, 255, 255, 0.88);
          transform: translateY(-1px);
          box-shadow: 0 12px 24px rgba(56, 189, 248, 0.14);
        }

        .filter-candy-shell .filter-toggle.active,
        .filter-candy-shell .color-chip.active {
          border-color: color-mix(in srgb, var(--accent) 58%, white 42%);
          background: linear-gradient(
            145deg,
            color-mix(in srgb, var(--accent, #f472b6) 24%, white 76%),
            color-mix(in srgb, var(--accent-2, #f59e0b) 20%, white 80%)
          );
          color: color-mix(in srgb, var(--text) 84%, #3f3f46 16%);
        }

        .filter-candy-shell .size-chip.active {
          background: linear-gradient(
            145deg,
            color-mix(in srgb, var(--accent, #f472b6) 70%, white 30%),
            color-mix(in srgb, var(--accent-2, #f59e0b) 64%, white 36%)
          );
          border-color: transparent;
        }

        .filter-candy-shell .size-chip {
          min-width: 0;
          width: auto;
          min-width: 4.1rem;
          min-height: 2.7rem;
          border-radius: 999px;
          padding: 0.55rem 0.95rem;
          justify-content: center;
          text-align: center;
          background: linear-gradient(
            150deg,
            rgba(252, 222, 239, 0.88),
            rgba(248, 222, 245, 0.76)
          );
          border-color: rgba(242, 160, 207, 0.56);
          box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.8),
            0 8px 16px rgba(15, 23, 42, 0.08);
        }

        .filter-candy-shell .size-chip:hover {
          border-color: rgba(255, 255, 255, 0.9);
          box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.9),
            0 12px 22px rgba(236, 72, 153, 0.16);
        }

        .filter-candy-shell .size-chip.active {
          box-shadow:
            0 12px 24px rgba(236, 72, 153, 0.24),
            0 8px 18px rgba(14, 165, 233, 0.16);
          border-color: transparent;
        }

        .filter-candy-shell .filter-toggle-indicator {
          background: rgba(255, 255, 255, 0.9);
          border: 1px solid rgba(255, 255, 255, 0.8);
        }

        .filter-candy-shell .filter-toggle.active .filter-toggle-indicator {
          background: linear-gradient(145deg, var(--accent), var(--accent-2));
          border-color: transparent;
        }

        .filter-candy-shell .clear-filters-btn {
          background: linear-gradient(145deg, rgba(254, 226, 226, 0.92), rgba(252, 165, 165, 0.34));
          border-color: rgba(252, 165, 165, 0.6);
          color: #be123c;
        }

        .filter-candy-shell .clear-filters-btn:hover {
          background: linear-gradient(145deg, rgba(254, 226, 226, 0.98), rgba(252, 165, 165, 0.44));
          transform: translateY(-1px);
        }

        .filter-candy-shell .filter-tag {
          background: linear-gradient(145deg, rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.72));
          border-color: rgba(255, 255, 255, 0.8);
          color: color-mix(in srgb, var(--text) 84%, #334155 16%);
          box-shadow: 0 8px 16px rgba(99, 102, 241, 0.08);
        }

        .filter-candy-shell .filter-tag-remove {
          background: linear-gradient(145deg, rgba(248, 113, 113, 0.22), rgba(239, 68, 68, 0.34));
          color: #b91c1c;
        }

        .filter-candy-shell .active-filters-count {
          box-shadow: 0 8px 16px rgba(244, 114, 182, 0.28);
        }

        @media (prefers-reduced-motion: reduce) {
          .filter-drawer-opening,
          .filter-drawer-closing,
          .filter-candy-shell .filter-section,
          .filter-candy-shell .filter-accordion,
          .filter-candy-shell .filter-tags,
          .filter-backdrop-candy.opening,
          .filter-backdrop-candy.closing {
            animation: none !important;
          }
        }

        @media (max-width: 640px) {
          .filter-candy-shell .size-chips-grid {
            gap: 0.5rem;
          }

          .filter-candy-shell .size-chip {
            min-height: 2.5rem;
            border-radius: 999px;
            font-size: 0.8rem;
            min-width: 3.85rem;
            padding: 0.5rem 0.82rem;
          }
        }
      `}</style>
    </div>
  );
}
