import React from "react";
import { notFound } from "next/navigation";
import { getPageBySlug } from "@/lib/api";
import { CmsPageRenderer } from "@/cms";

const MAP: Record<string, string> = {
  privacy: "privacy-policy",
  terms: "terms-of-service",
  refund: "refund-policy",
  shipping: "shipping-policy",
};

export default async function PolicyPage({ params }: { params: { key: string } }) {
  const slug = MAP[params.key];
  if (!slug) return notFound();

  const page = await getPageBySlug(slug);
  if (!page) return notFound();

  return <CmsPageRenderer sections={page.sections as any} />;
}
